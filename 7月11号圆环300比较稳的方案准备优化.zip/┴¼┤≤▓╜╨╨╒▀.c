/****************************��ʼ��*********************************/
/****************************��ʼ��*********************************/
/****************************��ʼ��*********************************/
#include "main.h"
#define uchar  unsigned char
#define uint   unsigned int          
int   leftdianci,rightdianci,r=0;  //unsigned
unsigned int   result1,result2,w,k,y=0;
unsigned char  celve = 0;
unsigned int   TimeCount = 0;
int            carspeed,left,fcha1,fcha0,j=0,c,a;
uint           zuixiaozhouqi=5;//ֱ����������
float          gyroscope_rate = 0,g,accelerometer_angle=0;
float          Acc_z = 0,Gyro = 0,t=0; 
float          chajiao=0,fchajiao=0,speedold=0.0;
float          speednew=0.0,speedout=0.0 ;
float          leftdc,rightdc,directionout,directionnew,directionold,sub,add;
float          ajifen=0,m=0,n=0.0,sum,fi=0.0;
float           siqu=10.0; //�������
uint           suduzhouqi=100;//�ٶȿ�������
uint           suduzhouqicushu=20;
float          zhilifenduan=12;
       float          pfenduan=3.8; //���޸� 3.5
       float          pfenduanzenyi=0.2;//���޸�0.2
float          dfenduan=60;
float          dfenduanzenyi=0.05;
                   int            set=0; 
    float          linyi=1332.0;//��������ƫ1656.
    float          linjiao=1399.0;//�Ӽ���ƫ 908.
    float          p=2.0,d=0.25;//p=2.0,d=0.28;/
                         float  	       P=0.5,D=0.0,I=0.0;//�ٶ�      P=0.5,D=-0.2,I=0.05
float          Pdirection=170.0,Ddirection=1100.0;//����  Pdirection=175.0,Ddirection=660.0;
float          motoroutr=0; //�ҵ��
float          motoroutl=0; //����
int            maichong;
uint           dianci=0,ci=0;
uint           diancizhouqi=15;
float          g,g0;
       uint           setsudu=40;
float             duan=50.0;
float             ec;
float            weifend=0.0;
float            zhuanxianlingpian=1216.0;
float            zhuanxiangtlyi;
             float           diancizenyip=25.0,diancizenyid=90.0;  // diancizenyip=15.0,diancizenyid=100.0;
float           ezenyi,eazenyi;
      float           diancip=75.0,diancid=400.0;//  diancip=120.0,diancid=390.0;
      
      float     g1,g2,jiasudud=0.0;
/****************************������·��Ƶ��*********************************/
/****************************������·��Ƶ��*********************************/
/****************************������·��Ƶ��*********************************/
void SetBusCLK_64M(void)
{   
    CLKSEL=0X00;				//disengage PLL to system
    PLLCTL_PLLON=1;			//turn on PLL
    SYNR =0xc0 | 0x07;                        
    REFDV=0x80 | 0x01; 
    POSTDIV=0x00;       //pllclock=2*osc*(1+SYNR)/(1+REFDV)=128MHz;
    _asm(nop);          //BUS CLOCK=64M
    _asm(nop);
    while(!(CRGFLG_LOCK==1));	  //when pll is steady ,then use it;
    CLKSEL_PLLSEL =1;		        //engage PLL to system; 
}

/****************************��ʼ���豸**************************************/

void DeviceInit()
{
	
	
	SetBusCLK_64M();
	UART_Init();

}


/****************************��ʼ���豸**************************************/
void Dly_ms(unsigned int ms) 
{
  unsigned int i,j;
  for(i=0;i<ms;i++)
  for(j=0;j<20000;j++);
}
/****************************��ʼ���豸**************************************/


void AD_Init(void) 
{ 

  ATD0CTL0=0x07;  //06   
  ATD0CTL1=0x4f; // TD0  05    TD1  4f  TD2  00  td3  a0   td4 30 
	ATD0CTL2=0x40;//     /*ʹ��ATDģ�����������־���������ⲿ����*/
	ATD0CTL3=0xc8;//b8  90   /*ֻת��һ��ͨ��*/
	ATD0CTL4=0x05;//     /*10λ���ȣ�12��Ƶ*/
	ATD0CTL5=0x30;// 0x32    /*�Ҷ��룬�޷��ţ�ɨ��ģʽ��ʹ��ͨ��0*/  �ӵ�3��ͨ����ʼ
}


/****************************��ʼ���豸**************************************/
void  Get_AD(void)
{
  
   while(!ATD0STAT0_SCF);   /*�ȴ���ǰ����ת�����*/
   result1=ATD0DR0;  //4
   result2=ATD0DR1;// 5
   leftdianci=ATD0DR2; //6   
   rightdianci=ATD0DR3; //7	    /*��ȡ����Ĵ����е�ֵ*/ 
   //zhuanxiangtlyi=ATD0DR4;//                
   ATD0STAT0_SCF=1;
   
 	                     /*���������ɱ�־*/
}
/****************************��ʼ���豸**************************************/


void  getmaicong()
  {  
if(PWMDTY1>0) 
        {
        c=PACNTL;
        PACNTL=0;
        }
     
     if(PWMDTY0>0) 
       {
       c=0-PACNTL;
       PACNTL=0;
        } 
     
     if(PWMDTY2>0) 
     {
     
             a=PORTA;
   
            
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=0;
            
     }
     
       if(PWMDTY3>0) 
     {
     
             a=0-PORTA;
   
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=1;
            PORTB_PB7=0;
             
     }  
     left=(a+c)/2;
   
  }


/****************************��ʼ���豸**************************************/
 void  speedkc(void)  //�ٶȿ���
 {
 // r++; 
//if(r==1)  set=90;
//if(r==20) set=130;
//if(r==40)   set=300;
//if(r==40)  set=280;
//if(r==60)  set=340;
//if(r==80)  set=setsudu+200;
//if(r==100)  set=setsudu+250;
carspeed=maichong;
maichong=0;
speedold=speednew;
fcha1=set-carspeed; 
//fi+=I*(fcha1);
speednew=fcha1*P+(fcha1-fcha0)*D;   //+fi

fcha0=fcha1;
if(speednew>=200)  speednew=200;
if(speednew<-200)   speednew=-200;

}


/****************************��ʼ���豸**************************************/
void  speedjs()//�ٶ����������
{   float  value;
    value=speednew-speedold;
    speedout=(value*(j+1)/suduzhouqi)+speedold;
 }


/****************************��ʼ���豸**************************************/
void PIT_init(void)
{
                     //����pt7��ʼ��
    PACTL = 0x40;    //������� �½���
    PACNT = 0x0000;  // Pulse Accumulators Count Registers (PACNT
   
    PITCFLMT_PITE=0; //��ʱ�ж�ͨ��0��
    PITCE_PCE0=1;    //��ʱ��ͨ��0ʹ��
    PITMTLD0=8-1;    //8λ��ʱ����ֵ�趨,8��Ƶ����64MHzBusClock�£�Ϊ8MHz����0.125us
    PITLD0=8000-1;   //16λ��ʱ����ֵ�趨��PITTIME*0.125uS  8000*0.125 =1ms��1mS�ж�һ��
    PITINTE_PINTE0=1;//��ʱ���ж�ͨ��0�ж�ʹ��
    PITCFLMT_PITE=1; //��ʱ��ͨ��0ʹ�� 
}


/****************************��ʼ���豸**************************************/

void PWM_Init(void) 

{ 
  PWME=0x00;  // Disable  PWM            ��ֹ             
  PWMPRCLK=0x55;    // 0011 0011 A=B=24M/8=3M  ʱ��Ԥ��Ƶ�Ĵ�������
  PWMSCLA=150;      // SA=A/2*150=10k          ʱ������
  PWMSCLB=150;      // SB=B/2*150 =10K         ʱ������                    
  PWMCLK=0x00;   // PWM3-----SB             ʱ��Դ��ѡ��
  PWMPOL=0x0f;   // Duty=High Time          ��������
  PWMCAE=0x00;    // Left-aligned            ���뷽ʽ����
  PWMCTL=0x00;      // no concatenation        ���ƼĴ������� 
  PWMPER0=200;
  PWMPER1=200;
  PWMPER2=200; 
  PWMPER3=200;   // T=PWMPER/SB             ���ڼĴ�������
  PWMDTY0=0; 
  PWMDTY1=0;
  PWMDTY2=0;
  PWMDTY3=0;
                  // Duty cycle = x%        ռ�ձȼĴ�������
  PWME=0x0f;      // Enable  PWM             ʹ��    




 
 /* PWME=0x00;  // Disable  PWM            ��ֹ             
  PWMPRCLK=0x55;    // 0011 0011 A=B=24M/8=3M  ʱ��Ԥ��Ƶ�Ĵ�������
  PWMSCLA=150;      // SA=A/2*150=10k          ʱ������
  PWMSCLB=150;      // SB=B/2*150 =10K         ʱ������                    
  PWMCLK=0x00;   // PWM3-----SB             ʱ��Դ��ѡ��
  PWMPOL=0x1b;   // Duty=High Time          ��������
  PWMCAE=0x00;    // Left-aligned            ���뷽ʽ����
  PWMCTL=0x00;      // no concatenation        ���ƼĴ������� 
  PWMPER0=200;
  PWMPER1=200;
  PWMPER4=200; 
  PWMPER3=200;   // T=PWMPER/SB             ���ڼĴ�������
  PWMDTY0=0; 
  PWMDTY1=0;
  PWMDTY4=0;
  PWMDTY3=0;
             // Duty cycle = x%        ռ�ձȼĴ�������
  PWME=0x1b;     // Enable  PWM             ʹ��  
  */        
}


/****************************��ʼ���豸**************************************/
/****************************��ʼ���豸**************************************/
void  pchabiao()// ���

{ if(ajifen<=zhilifenduan&&ajifen>=-zhilifenduan)             {   p=pfenduan;                 }
   if(ajifen<=(zhilifenduan+12)&&ajifen>zhilifenduan)          {   p=pfenduan+pfenduanzenyi;   }  
   if(ajifen<-zhilifenduan&&ajifen>=-(zhilifenduan+12))        {   p=pfenduan+pfenduanzenyi;   }
   if(ajifen<=(zhilifenduan+24)&&ajifen>=(zhilifenduan+12))    {   p=pfenduan+pfenduanzenyi*2; }
   if(ajifen<-(zhilifenduan+12)&&ajifen>=-(zhilifenduan+24))   {   p=pfenduan+pfenduanzenyi*2; }
   if(ajifen<=(zhilifenduan+36)&&ajifen>(zhilifenduan+24))     {   p=pfenduan+pfenduanzenyi*3; } 
   if(ajifen<-(zhilifenduan+24)&&ajifen>=-(zhilifenduan+36))   {   p=pfenduan+pfenduanzenyi*3; }
   if(ajifen<=(zhilifenduan+48)&&ajifen>(zhilifenduan+36))     {   p=pfenduan+pfenduanzenyi*4; }
   if(ajifen<-(zhilifenduan+36)&&ajifen>=-(zhilifenduan+48))   {   p=pfenduan+pfenduanzenyi*4; }
    

   

}

/****************************��ʼ���豸**************************************/
/****************************��ʼ���豸**************************************/
void  dchabiao() 
{  if(gyroscope_rate<=60&&gyroscope_rate>=-60)  {  d=0.15;          }  
   if(gyroscope_rate<=100&&gyroscope_rate>60)   {  d=0.2;          }
   
   if(gyroscope_rate<-60&&gyroscope_rate>-100)  {  d=0.2;          }
   if(gyroscope_rate<=160&&gyroscope_rate>100)  {  d=0.25;          }
   if(gyroscope_rate<-100&&gyroscope_rate>-160) {  d=0.25;          }
   if(gyroscope_rate<=230&&gyroscope_rate>160)  {  d=0.3;          }
   if(gyroscope_rate<-160&&gyroscope_rate>-230) {  d=0.3;          }
   if(gyroscope_rate<=300&&gyroscope_rate>230)  {  d=0.3;           }
   if(gyroscope_rate<-230&&gyroscope_rate>-300)  {  d=0.3;           }


 
 
}



/****************************����������*********************************/
/****************************����������*********************************/
/***************************����������*********************************/
void  mortorouto() 

{  

      
      speedjs();
    
      motoroutr=((p*ajifen+d*gyroscope_rate)+speedout)+directionout;
      motoroutl=((p*ajifen+d*gyroscope_rate)+speedout)-directionout;
if(ajifen>330.0||ajifen<-330.0)
                       {  
                       PWMDTY1=0;
                       PWMDTY3=0;
                       PWMDTY0=0; 
                       PWMDTY2=0; 
                       }
/****************************����������*********************************/
/***************************����������*********************************/                       
  else {      
 /***************************�ҵ���������*********************************/                     
                if(motoroutr>=0) 
                                 {  
                                  if(motoroutr<200)
                                  {         
                                                 
                                  PWMDTY3=motoroutr+siqu;
                                
                                  PWMDTY2=0; 
                                  } 
                                  
                                  else 
                                  {
                                  PWMDTY3=200;
                                  
                                  PWMDTY2=0;
                                  }
                                  
                                 }




                   else
                               {  
                                     if(motoroutr>-200) 
                                     {
                                      
                                      PWMDTY3=0;
                                     
                                      PWMDTY2=-(motoroutr-siqu);
                                     } 
                                     else 
                                     {
                                      PWMDTY3=0;
                                     
                                      PWMDTY2=200;
                                     }
                                           
                               }


/***************************�����������*********************************/ 


                    if(motoroutl>=0) 
                                 {  
                                  if(motoroutl<200)
                                  {
                                  
                                  PWMDTY0=motoroutl+siqu;
                                
                                  PWMDTY1=0; 
                                  } 
                                  
                                  else 
                                  {
                                  PWMDTY0=200;
                                  
                                  PWMDTY1=0;
                                  }
                                  
                                 }




                  else
                               {  
                                     if(motoroutl>-200) 
                                     {
                                      
                                      PWMDTY0=0;
                                     
                                      PWMDTY1=-(motoroutl-siqu);
                                     } 
                                     else 
                                     {
                                      PWMDTY0=0;
                                     
                                      PWMDTY1=200;
                                     }
                                           
                               }
                   
   /***************************������������*********************************/                     
                         
                 }
         
         
      if(leftdianci<160&&rightdianci<150)   
         
      {    PWMDTY2=0;
                                     
          PWMDTY3=0;
      
             PWMDTY0=0;
                                     
          PWMDTY1=0;
      }
         
                   

}

/****************************����������*********************************/
/***************************����������*********************************/   

 int AXFilter(void) //��ƽ��ֵ���˲�����
{
  uint i,j,Max,Min,Average=0,Max2,Min2, Average2 =0;
  uint Data[20],Data2[20];
  for(i=0;i<20;i++)        //�ɼ�����
   { Get_AD();
      Data[i]=result1;
      Data2[i]=result2;
   }
  Max=Min=Data[0];
  Max2=Min2=Data2[0];
  for(i=1;i<20;i++) 		//Ѱ����ֵ
  {
    if( Data[i] > Max )
      Max=Data[i];
    if( Data[i] < Min )
      Min=Data[i];
  }
      for(i=1;i<20;i++) 		//Ѱ����ֵ
  {
    if( Data2[i] > Max2 )
      Max2=Data2[i];
    if( Data2[i] < Min2 )
      Min2=Data2[i];
  }
  
  for(i=0;i<20;i++)
  Average += Data[i];
  for(i=0;i<20;i++)
  Average2 += Data2[i];
  Average = Average -Max -Min; //ȥ����ֵ����ƽ��	
  Average = Average/18;
  w = Average;
 	k= (Average2-Max2 -Min2)/18;

}   

/****************************����������*********************************/

 void kalman_update(void)
{
	 
	 
	  
	 
	  
     
 
   	   Gyro= k  -linyi;//x��ˮƽ�����ֵ   17    10 Acc_z=  k  - 1622.0
   	
   	   Acc_z= w - linjiao; //������ֱ�����������ֵ 03   Gyro  =  w - 1503.0
   	
       ajifen= Acc_z;           
    
       gyroscope_rate=-Gyro;
    
    /* accelerometer_angle= Acc_z*0.136;//0.136
       t=-accelerometer_angle;
       OutData[0]=-(accelerometer_angle*100); // ��ע�� �����ֵ��Ϊ��������κ�ʱ�̽���һ��
    
       gyroscope_rate = Gyro*0.21;//ʮ��0.182���屶0.324��0.35   0.168 0.156
       OutData[2]=gyroscope_rate*11 ;
       ajifen=sum;
       chajiao= t-ajifen;

       fchajiao= (t-ajifen)*2;//2  1.8
       sum+=(gyroscope_rate+fchajiao)*(0.005);
       OutData[1] =ajifen*100; 

      
          */                                  
    

}
void  diancipchacunp()

  {if((g<=0.1)&&(g>=-0.1))                                {   Pdirection= 40;                 }
   if((g<=0.15)&&(g>0.1))                                 {   Pdirection=80;   }  
   if((g<-0.1)&&(g>-0.15))                                {   Pdirection= 80;   }
  
  
  //if((g<=0.1)&&(g>=-0.1))                                {   Pdirection= diancip;                 }
   //if((g<=0.15)&&(g>0.1))                                 {   Pdirection= diancip+ diancizenyip;   }  
   //if((g<-0.1)&&(g>-0.15))                                {   Pdirection= diancip+ diancizenyip;   }
   if((g<=0.2)&&(g>=0.15))                                {   Pdirection= diancip+ diancizenyip*2; }
  if((g<-0.15)&&(g>=-0.2))                               {   Pdirection= diancip+ diancizenyip*2; }
   if((g<=0.25)&&(g>0.2))                                  {   Pdirection= diancip+ diancizenyip*2; } 
   if((g<-0.2)&&(g>=-0.25))                                {   Pdirection= diancip+ diancizenyip*2; }
   if((g<=0.3)&&(g>0.2))                                  {   Pdirection= diancip+ diancizenyip*3; }
   if((g<-0.2)&&(g>=-0.3))                                {   Pdirection= diancip+ diancizenyip*3; }
   if((g<=0.5)&&(g>0.3))                                  {   Pdirection= diancip+ diancizenyip*4; }
   if((g<-0.3)&&(g>=-0.5))                                {   Pdirection= diancip+ diancizenyip*4; }
   if((g<=0.8)&&(g>0.5))                                  {   Pdirection= 150.0; }
   if((g<-0.5)&&(g>=-0.8))                                {   Pdirection= 150.0; }
 
    if((g<=1.0)&&(g>0.8))                                  {   Pdirection= 150.0; }
   if((g<-0.8)&&(g>=-1.0))                                {   Pdirection= 150.0; }
    // if((g<=0.8)&&(g>0.5))                                  {   Pdirection= diancip+ diancizenyip*6; }
   //if((g<-0.5)&&(g>=-0.8))                                {   Pdirection= diancip+ diancizenyip*6; }
 
    //if((g<=1.0)&&(g>0.8))                                  {   Pdirection= diancip+ diancizenyip*6; }
  // if((g<-0.8)&&(g>=-1.0))                                {   Pdirection= diancip+ diancizenyip*6; }
  
  
  
  }


 void  diancipchacund()

  { if((ec<=0.0125)&&(ec>=-0.0125))                             {   Ddirection=600.0;                  }
  if((ec<=0.025)&&(ec>0.0125))                                {   Ddirection=600.0;     }  
 if((ec<-0.0125)&&(ec>=-0.025))                              {   Ddirection=600.0;     }
  
  
  //if((ec<=0.0125)&&(ec>=-0.0125))                             {   Ddirection=diancid;                  }
//  if((ec<=0.025)&&(ec>0.0125))                                {   Ddirection=diancid+diancizenyid;     }  
 // if((ec<-0.0125)&&(ec>=-0.025))                              {   Ddirection=diancid+diancizenyid;     }
  if((ec<=0.05)&&(ec>=0.025))                                 {   Ddirection=diancid+diancizenyid*2.5; }
   if((ec<-0.025)&&(ec>=-0.05))                                {   Ddirection=diancid+diancizenyid*2.5; }
   if((ec<=0.1)&&(ec>0.05))                                  {   Ddirection=diancid+diancizenyid*3,5; } 
   if((ec<-0.05)&&(ec>=-0.1))                                {   Ddirection=diancid+diancizenyid*3.5; }
   if((ec<=0.15)&&(ec>0.05))                                  {   Ddirection=diancid+diancizenyid*4.5; }
   if((ec<-0.05)&&(ec>=-0.1))                                {   Ddirection=diancid+diancizenyid*4.5; }
   if((ec<=0.2)&&(ec>0.1))                                  {   Ddirection=diancid+diancizenyid*5;   }
   if((ec<-0.1)&&(ec>=-0.2))                                {   Ddirection=diancid+diancizenyid*5;   }
   //if((ec<=0.5)&&(ec>0.2))                                   {   Ddirection=0.0;   }
   //if((ec<-0.2)&&(ec>=-0.5))                                 {   Ddirection=0.0;   }
  // if((ec<=0.8)&&(ec>0.5))                                   {   Ddirection=0.0;   }
   //if((ec<-0.5)&&(ec>=-0.8))                                 {   Ddirection=0.0;   }
     
     if((ec<=0.5)&&(ec>0.2))                                   {   Ddirection=diancid+diancizenyid*6;   }
 if((ec<-0.2)&&(ec>=-0.5))                                 {   Ddirection=diancid+diancizenyid*6;   }
  if((ec<=0.8)&&(ec>0.5))                                   {   Ddirection=diancid+diancizenyid*6;   }
   if((ec<-0.5)&&(ec>=-0.8))                                 {   Ddirection=diancid+diancizenyid*6;   }
  
  
  
  } 


      



/***************************����������*********************************/ 
void   directionkc()  //�������

{  leftdc=leftdianci; //280
   rightdc=rightdianci;//280
   sub=leftdc-rightdc;  
   add=leftdianci+rightdianci;
   g=sub/add;  // g=sub/480;
   if(g>1)   g=1;
   if(g<-1)   g=-1;
   
   /************************************************************/
   
   ec=g-g2;
 //  if(((g>0.85)&&(g<1))||((g>-1)&&(g<-0.85)))   {Pdirection=85; Ddirection=5;}
   
   
   

  /*  if(((g>0.5)&&(g<0.85))||((g>-0.85)&&(g<-0.5)))   
    {if(((ec>0.0)&&(ec<0.1))||((ec>-0.1)&&(ec<0.0)))      {Pdirection=85; Ddirection=25; }
     if(((ec>0.1)&&(ec<0.25))||((ec>-0.25)&&(ec<-0.1)))   {Pdirection=85; Ddirection=75; }
     if(((ec>0.25)&&(ec<0.4))||((ec>-0.4)&&(ec<-0.25)))   {Pdirection=85; Ddirection=95;}
     if(((ec>0.4)&&(ec<0.8))||((ec>-0.8)&&(ec<-0.4)))     {Pdirection=85; Ddirection=135;}
    }
    
   if(((g>0.3)&&(g<0.5))||((g>-0.5)&&(g<-0.3)))   
    {if(((ec>0.0)&&(ec<0.1))||((ec>-0.1)&&(ec<0.0)))      {Pdirection=65; Ddirection=135; }
     if(((ec>0.1)&&(ec<0.25))||((ec>-0.25)&&(ec<-0.1)))   {Pdirection=65; Ddirection=175; }
     if(((ec>0.25)&&(ec<0.4))||((ec>-0.4)&&(ec<-0.25)))   {Pdirection=65; Ddirection=225;}
     if(((ec>0.4)&&(ec<0.8))||((ec>-0.8)&&(ec<-0.4)))     {Pdirection=65; Ddirection=275;}
    }
    
  
    
    
   if(((g>0.0)&&(g<0.3))||((g>-0.3)&&(g<0.0)))   
    {if(((ec>0.0)&&(ec<0.1))||((ec>-0.1)&&(ec<0.0)))      {Pdirection=95; Ddirection=300; }
     if(((ec>0.1)&&(ec<0.25))||((ec>-0.25)&&(ec<-0.1)))   {Pdirection=95; Ddirection=340; }
     if(((ec>0.25)&&(ec<0.4))||((ec>-0.4)&&(ec<-0.25)))   {Pdirection=95; Ddirection=370;}
     if(((ec>0.4)&&(ec<0.8))||((ec>-0.8)&&(ec<-0.4)))     {Pdirection=95; Ddirection=290;}
    } 
    
    /************************************************************/
   
   //  diancipchacunp();
  // diancipchacund();
       
       
   
   directionold=directionnew;                  //������-1��+1֮��   ƫ��   ����PD
   directionnew=g*Pdirection+Ddirection*(g-g2)+jiasudud*(g+g1-2*g2);
      
       g1=g2;
      g2=g;
      
   
  // g0=g;
   if(directionnew>195.0)  directionnew=195.0; 
   if(directionnew<-195.0)  directionnew=-195.0; 
   
   
     
 
}                   



/***************************����������*********************************/ 
void  directionshuchu() 
 {  float  value1;
    value1=directionnew-directionold;
    directionout=(value1*(dianci+1))/diancizhouqi+directionold;
 
 
 }

/***************************����������*********************************/ 
/***************************����������*********************************/    

#pragma CODE_SEG __NEAR_SEG NON_BANKED //ָʾ�ó����ڲ���ҳ��
void interrupt 66 PIT0(void) 
{     
      
        j++;
        if(j>=suduzhouqi)   j=0;
        dianci++;
        if(dianci>=diancizhouqi)   dianci=0;
   
      //  directionshuchu(); 
       
        TimeCount++;
      
if( TimeCount>=zuixiaozhouqi) 
       {
  
         TimeCount=0;
       }
      
else if( TimeCount==1) 
       {    
         AXFilter();
                
       }
else if( TimeCount==2) 
       {  
        kalman_update();  //��ʼ�˲���ýǶȣ����ٶ�
             
       }  
else if( TimeCount==3) 
       { 
           pchabiao();
         dchabiao() ;
mortorouto();
             
       }
else if( TimeCount==4) 
      {           
                  y++;
                  ci++; 
                 directionshuchu();    
               if((y%5)==0) 
                      {   getmaicong();
                          maichong+=left;
                          left=0; 
                      }
                if(y==suduzhouqicushu) 
                    {       y=0;
                      speedkc();
                    }  
                if(ci==3) 
                   {         ci=0;
                      directionkc() ;//�������  
                   }  
                          
               
        
               
                   
                  
               
      
       }
  
  
  
  
   PITTF_PTF0=1;//���жϱ�־λ


}

void   suduxuanzhe()

{ 
   if((PORTB_PB0==1)&&(PORTB_PB1==0)&&(PORTB_PB2==0)&&(PORTB_PB3==0))  set=5; 
   if((PORTB_PB0==0)&&(PORTB_PB1==1)&&(PORTB_PB2==0)&&(PORTB_PB3==0))  set=10;  
   if((PORTB_PB0==1)&&(PORTB_PB1==1)&&(PORTB_PB2==0)&&(PORTB_PB3==0))  set=15; 
   if((PORTB_PB0==0)&&(PORTB_PB1==0)&&(PORTB_PB2==1)&&(PORTB_PB3==0))  set=120; 
   if((PORTB_PB0==1)&&(PORTB_PB1==0)&&(PORTB_PB2==1)&&(PORTB_PB3==0))  set=140; 
   if((PORTB_PB0==0)&&(PORTB_PB1==1)&&(PORTB_PB2==1)&&(PORTB_PB3==0))  set=180; 
   if((PORTB_PB0==1)&&(PORTB_PB1==1)&&(PORTB_PB2==1)&&(PORTB_PB3==0))  set=220; 
   if((PORTB_PB0==0)&&(PORTB_PB1==0)&&(PORTB_PB2==0)&&(PORTB_PB3==1))  set=260; 
   if((PORTB_PB0==1)&&(PORTB_PB1==0)&&(PORTB_PB2==0)&&(PORTB_PB3==1))  set=300; 
   if((PORTB_PB0==0)&&(PORTB_PB1==1)&&(PORTB_PB2==0)&&(PORTB_PB3==1))  set=360;  
   if((PORTB_PB0==1)&&(PORTB_PB1==1)&&(PORTB_PB2==0)&&(PORTB_PB3==1))  set=390; 
   if((PORTB_PB0==0)&&(PORTB_PB1==0)&&(PORTB_PB2==1)&&(PORTB_PB3==1))  set=400; 
   if((PORTB_PB0==1)&&(PORTB_PB1==0)&&(PORTB_PB2==1)&&(PORTB_PB3==1))  set=420; 
   if((PORTB_PB0==0)&&(PORTB_PB1==1)&&(PORTB_PB2==1)&&(PORTB_PB3==1))  set=460; 
   if((PORTB_PB0==1)&&(PORTB_PB1==1)&&(PORTB_PB2==1)&&(PORTB_PB3==1))  set=490; 
  
 
}
/************************************************************/ 
/************************************************************/ 
/************************************************************/ 
/************************************************************/ 
void main(void)
    {     
           uint r; 
           EnableInterrupts;
           DDRB=0x80;
           PORTB_PB7=1;
           PORTB_PB7=1;
           PORTB_PB7=1;
           PORTB_PB7=1;
           PORTB_PB7=1;
           PORTB_PB7=1;
           PORTB_PB7=1;
           PORTB_PB7=1;
           PORTB_PB7=1;
           PORTB_PB7=1 ;
        
           PORTB_PB7=0;
           DDRA=0x00;
           PWM_Init();
           DeviceInit();
   	       AD_Init();
   	       suduxuanzhe(); //���뿪��   �ٶ�ѡ������ ��ͨ   �͵�ƽ
   	      //   Dly_ms(1500);����  ��ͨ   �͵�ƽ
   	       PIT_init(); 
           //uart_putstr("Usart Is Working!");
             

          while(1)
            {    
            // OutPut_Data(); //��ʾ����
      
 
            }

}

