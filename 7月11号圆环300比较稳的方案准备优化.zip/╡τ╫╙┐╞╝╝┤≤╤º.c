#include"alldefine.h"
#include"carsub.h"
#include"support_common.h" /* include peripheral declarations and more */
#include"UART.h"
#include"Debug.h"
//#define filter  //�˲����Կ���
void main(void)
{
	unsigned char Array[8] = { 0},Rcvbuf[2] = {0};
	int i = 0;
	static float send1[8];
	static int temp_r = 0;
	#ifdef filter
	UartInit(0,80,9600,0);//�������ڳ�ʼ����ע�����������
	#else
	UartInit(0,80,115200,0);//�������ڳ�ʼ����ע�����������
	#endif
	All_init();
    Cardebug(); 
	for(;;)
	{ 
		//MCF_GPIO_PORTNQ |= MCF_GPIO_PORTNQ_PORTNQ1; 
     	CheckCarStand();
     	somesets();//��ز������� 
     	#ifndef filter
     	if((temp_rec == 1)&&(!((g_fCarAngle>MAXERRANGLE)||(g_fCarAngle<MINERRANGLE)||(g_LoseLineFlag == 1)||(!L_flag))))
     	{
     			for(i=0;i<Tran_Bytenum;i++)
     			{
     				UartSend1(0, send[i]);	
     			}
				temp_rec = 0;	
     	}
     	#else 
     	if(temp_r == 0)
     	{
     		send1[0] = g_fCarAngle;
     		send1[1] = g_foriginal_angle;
     		send1[2] = VOLTAGE_RIGHT;
     		send1[3] = g_fSpeedControlOut*100;
     		send1[4] = g_fAngleControlOut*100;
     		send1[5] = g_fDirectionControlOut*100;
     		send1[6] = g_fLeftMotorOut*100;
     		send1[7] = g_fRightMotorOut*100;
     		temp_r = 1;
     	}
     	if((temp_r == 1))//&&(!((g_fCarAngle>30)||(g_fCarAngle<-50)||(g_LoseLineFlag == 1)||(!L_flag))))
     	{
     			UartSend1(0, 0xf1);
     			for(i=0;i<2;i++)
     			{
     				UartSend1(0, (int8)send1[i]);
					UartSend1(0, (int8)((int)send1[i]>>8));	
     			}
				UartSend1(0, 0xf2);	
				temp_r = 0;	
     	}
     	#endif
	}
}

#define carsub_global
#include"UART.h"
#include"Debug.h"
#include"stdio.h"
#include"carsub.h"
#include"support_common.h"
#include "math.h"
void CarSubInit(void)//��ȫ�ֱ�����ʼ��
{
   int i;
    L_flag = 0;
    temp_rec = 0;
   	g_nDirection_Selflag = 1;//Ĭ��ѡ���Ŵ�����
   	g_SensorChooseFlag = 1;//�������л���־
    g_StartCount = 0;//�𲽼���
    g_nStartSpeed = 20;
    g_nStartTime = 3;
    g_nSpeedMax_Int = 15;
    g_ntempcount = 0;
    g_timecount = 0;
	g_fLeftMotorOut = 0; //���ֵ�����
	g_fRightMotorOut = 0;//���ֵ�����
	g_fAngleControlOut = 0;//�Ƕ����������
	g_fSpeedControlOut = 0;//�ٶȿ��������
	g_fDirectionControlOut = 0;//������������
	g_nLeftMotorPulseSigma = 0;
	g_nRightMotorPulseSigma = 0;
	count = 0;//�������
	g_fCarSpeed = 0;
  	g_nSpeedControlPeriod = 0;
  	g_nCarSpeedSet = 34;//�����ٶȣ�������������������������
  	g_nCarSpeedSet_temp = g_nCarSpeedSet;
  	g_fSpeedControlIntegral = 0;
  	g_fSpeedControlOutOld = 0;
  	g_fSpeedControlOutNew = 0;
  	//--------------------------------��Ҫ����---------------------------------	
  	g_fSPEED_CONTROL_P = 0.95;//�ٶ�P����
  	g_fSPEED_CONTROL_P_temp = g_fSPEED_CONTROL_P;
  	g_fSPEED_CONTROL_I = 0.0077;//0.0477;//�ٶ�I����
  	g_fSPEED_CONTROL_D = 0;
    g_ANGLE_CONTROL_P = 0.2088;//0.26	//�Ƕ�P����			
 	g_ANGLE_CONTROL_D = 0.3030;//0.00345//�Ƕ�D����
 	g_ANGLE_CONTROL_I = 0.00000;//�Ƕ�I����
 	g_fDIRECTION_CONTROL_P = 0.0812;//����P����
 	g_fDIRECTION_CONTROL_D = 1.5700;
 	g_fDIRECTION_CONTROL_I = 0.0;
 	//--------------------------------��Ҫ����---------------------------------	
  	g_fLeftVoltageSigma1 = 0;
  	g_fRightVoltageSigma1 = 0;
  	
  	g_nDirectionControlPeriod = 0;
  	g_nDirectionControlFlag = 1;//��Ϊ0��ص��������
  	g_nAngleControlFlag = 0;
  	g_fDirectionControlOutOld = 0;
  	g_fLeftRightSub_old=0;
  	g_fDirectionControlOutNew = 0;
  	g_fDirection_add45min_L = 10000;//�ȸ�һ���ϴ��ֵ���Ա��ʼ��ʱ�޸�
  	g_fDirection_add45min_R = 10000;
	g_fDirection_sub18max = -10000;//�ȸ�һ����С��ֵ���Ա��ʼ��ʱ�޸�
  	g_fDirection_sub18min = 10000;
  	
  	
  	
  	
  	g_nSpeedControlFlag = 0;
  	
  	//------------------------------------------------------------
  	  g_fgyroscopestandard=1967;
  	  g_fanglezstandard =1790;//3148   2868//2970
  	  g_fGyroscopeAngleIntegral=0;
  	  
  	  
  	  g_nInputVoltageCount=0;
  	  g_nADresult=0;

 	  g_fangleratio=0.1363;
 	  g_cmeumselectnew = 0;
 	  g_ckeyvalue = 0;
 	  g_nCurveFlag = 0;
 	  g_BeepEnableFlag = 0;
 	  g_StraitEnableFlag = 0;
 	  g_CurveIntFlag = 0;
 	  g_StraightAddTime = 99;
 	  g_AddSpdPeriod = 50;
 	  g_AddSpdPeriod2 = 50;
  	  for(i=0;i<10;i++)
  	  {
  	    g_lnInputVoltageSigma[i]=0;
        g_nInputVoltage[i]=0;	
  	  }
}
void Delay10us(void)
{
    int ii;
	for(ii=0;ii<200;ii++)
	{
		;
	}
}

void MotorOutput(void)//����������
{
	float fLeft,fRight;
	static uint32 i,Temp_count = 0;
	Temp_count++;
	if((int)g_nCarSpeedSet_temp == 5)//�������
	{
		fRight =  g_fDirectionControlOut + g_fAngleControlOut ;
		fLeft  =  - g_fDirectionControlOut + g_fAngleControlOut ;
	}
	else if(((int)g_nCarSpeedSet_temp == 6)||((int)g_nCarSpeedSet_temp == 7))//6ֱ������,7�ٶȱջ�
	{
		fRight =  g_fAngleControlOut ;
		fLeft  =  g_fAngleControlOut ;		
	}
	else  //�������
	{
			fRight = g_fAngleControlOut + g_fDirectionControlOut ;
			fLeft  = g_fAngleControlOut - g_fDirectionControlOut ;
	}
/*	if(Temp_count%10==0)
	{
	if(!((g_fCarAngle>40)||(g_fCarAngle<-40)||(g_LoseLineFlag == 1)||(L_flag == 0))) 
    {
    	for(i=(RECORD_PAGENUM*24-2);i>0;i-=2)
    	{
    		g_err_rec[i+1] = g_err_rec[i-1];
    		g_err_rec[i]   = g_err_rec[i-2];
    	}
    	g_err_rec[0] = g_fAngleControlOut*100;
    	g_err_rec[1] = g_fDirectionControlOut*100;
    }	
	}*/
	if((ABS(fRight)>1)||(ABS(fLeft)>1))
	{
		BEEP_ON;
		if((ABS(g_fDirectionControlOut)>=0.4)&&(ABS(g_fAngleControlOut)>=0.6))
		{
			g_fDirectionControlOut = (float)(0.4*g_fDirectionControlOut/(ABS(g_fDirectionControlOut)));
			g_fAngleControlOut = (float)(0.6*g_fAngleControlOut/(ABS(g_fAngleControlOut)));
		}
		else if((ABS(g_fDirectionControlOut)>=0.4))
		{
			g_fDirectionControlOut = (1-ABS(g_fAngleControlOut))*g_fDirectionControlOut/(ABS(g_fDirectionControlOut));
		}
		else if((ABS(g_fAngleControlOut)>=0.6))
		{
			g_fAngleControlOut = (1-ABS(g_fDirectionControlOut))*g_fAngleControlOut/(ABS(g_fAngleControlOut));
		}
		fRight = g_fAngleControlOut + g_fDirectionControlOut ;
		fLeft  = g_fAngleControlOut - g_fDirectionControlOut ;
	}		
	else 
	{
		BEEP_OFF;	
	}
	g_fRightMotorOut = fRight;
	g_fLeftMotorOut = fLeft;
	
	if((g_fCarAngle>MAXERRANGLE)||(g_fCarAngle<MINERRANGLE)||(g_LoseLineFlag == 1))
	{
		g_fRightMotorOut = 0;
		g_fLeftMotorOut = 0;
	}
			
	if(g_fLeftMotorOut > MOTOR_OUT_MAX)	g_fLeftMotorOut = MOTOR_OUT_MAX;//����޷�
	if(g_fLeftMotorOut < MOTOR_OUT_MIN)	g_fLeftMotorOut = MOTOR_OUT_MIN;
	if(g_fRightMotorOut > MOTOR_OUT_MAX)	g_fRightMotorOut = MOTOR_OUT_MAX;
	if(g_fRightMotorOut < MOTOR_OUT_MIN)	g_fRightMotorOut = MOTOR_OUT_MIN;
	SetMotorVoltage();
}
void SetMotorVoltage(void) //PWM�������
{
    #define nPeriod 255                                             
	uint8 nOut;                                        	                                            	                                              
	if(g_fLeftMotorOut > 0) {   //������ת(ע��У��������)
		MCF_PWM_PWMDTY(0) = 0; 	//��ת����
		nOut = (uint8)(g_fLeftMotorOut * nPeriod);
		MCF_PWM_PWMDTY(2) = nOut;
	} else {					//���ַ�ת
		MCF_PWM_PWMDTY(2) = 0;//��ת����
		nOut = (uint8)(-g_fLeftMotorOut * nPeriod);
		MCF_PWM_PWMDTY(0) = nOut;
	}                                     
	if(g_fRightMotorOut > 0) {			//������ת
		MCF_PWM_PWMDTY(1) = 0;//��ת����
		if((g_fRightMotorOut * nPeriod)>255)
		nOut = 255;
		else
		nOut = (uint8)(g_fRightMotorOut * nPeriod);
		MCF_PWM_PWMDTY(3) = nOut;//+10 ���ֲ���	
	} else {						//���ַ�ת
		MCF_PWM_PWMDTY(3) = 0; //��ת����			
		if((-g_fRightMotorOut * nPeriod)>255)
		nOut=255;
		else
		nOut = (uint8)(-g_fRightMotorOut * nPeriod);
		MCF_PWM_PWMDTY(1) =nOut; 
	}

}          

void PWM_init(void)  //PWMģ���ʼ��
{
	MCF_GPIO_PUAPAR &= 0x3f;//����оƬʹ��3
	MCF_GPIO_PNQPAR &= 0x3fff;//����оƬʹ��7
	MCF_GPIO_DDRUA  |=0x08;
	MCF_GPIO_DDRNQ  |=0x80;
	MCF_GPIO_PORTUA	|=MCF_GPIO_PORTUA_PORTUA3;
	MCF_GPIO_PORTNQ |=0x80;
	MCF_GPIO_PTCPAR=MCF_GPIO_PTCPAR_DTIN0_PWM0
				   |MCF_GPIO_PTCPAR_DTIN1_PWM2;
	MCF_GPIO_PTAPAR=MCF_GPIO_PTAPAR_ICOC0_PWM1
				   |MCF_GPIO_PTAPAR_ICOC1_PWM3;			   
				   
	MCF_PWM_PWMPOL=MCF_PWM_PWMPOL_PPOL0//���øߵ�ƽ��ʼ
				  |MCF_PWM_PWMPOL_PPOL1
				  |MCF_PWM_PWMPOL_PPOL2
				  |MCF_PWM_PWMPOL_PPOL3
				  |MCF_PWM_PWMPOL_PPOL4
				  |MCF_PWM_PWMPOL_PPOL5
				  |MCF_PWM_PWMPOL_PPOL6
				  |MCF_PWM_PWMPOL_PPOL7;
	MCF_PWM_PWMCLK=MCF_PWM_PWMCLK_PCLK0 //ѡ��ʱ��SA 
				  |MCF_PWM_PWMCLK_PCLK1 //ѡ��ʱ��SA 
				  |MCF_PWM_PWMCLK_PCLK2 //ѡ��ʱ��SB
				  |MCF_PWM_PWMCLK_PCLK3 //ѡ��ʱ��SB
				  |MCF_PWM_PWMCLK_PCLK4 //ѡ��ʱ��SA 
				  |MCF_PWM_PWMCLK_PCLK5 //ѡ��ʱ��SA 
				  |MCF_PWM_PWMCLK_PCLK6 //ѡ��ʱ��SB
				  |MCF_PWM_PWMCLK_PCLK7;//ѡ��ʱ��SB
	MCF_PWM_PWMPRCLK=MCF_PWM_PWMPRCLK_PCKA(2)
					|MCF_PWM_PWMPRCLK_PCKB(2);//����ʱ��A��BԤ��Ƶ
	MCF_PWM_PWMCAE=(byte)(~(MCF_PWM_PWMCAE_CAE0   //�����
				  |MCF_PWM_PWMCAE_CAE1
				  |MCF_PWM_PWMCAE_CAE2
				  |MCF_PWM_PWMCAE_CAE3
				  |MCF_PWM_PWMCAE_CAE4
				  |MCF_PWM_PWMCAE_CAE5
				  |MCF_PWM_PWMCAE_CAE6
				  |MCF_PWM_PWMCAE_CAE7)); 
	MCF_PWM_PWMCTL=0x00;//δ����
	MCF_PWM_PWMSCLA=4;//ʱ�ӷ�Ƶ
	MCF_PWM_PWMSCLB=4;
	MCF_PWM_PWMCNT0=0;  //��������ʼ����
	MCF_PWM_PWMCNT2=0;
	MCF_PWM_PWMCNT1=0;
	MCF_PWM_PWMCNT3=0;
	MCF_PWM_PWMPER2=255;
	MCF_PWM_PWMPER0=255;
	MCF_PWM_PWMPER1=255;
	MCF_PWM_PWMPER3=255;
	MCF_PWM_PWMDTY(2)=0;
	MCF_PWM_PWMDTY(0)=0;
	MCF_PWM_PWMDTY(1)=0;
	MCF_PWM_PWMDTY(3)=0;
	MCF_PWM_PWMSDN=MCF_PWM_PWMSDN_IF;
	MCF_PWM_PWME=0xff;
}
void AD_init(void)
{
    MCF_ADC_CTRL1=0x4002;//�������룬˳��ѭ��ɨ�裬����ģʽ���ȶ�
    MCF_ADC_CTRL2=0x0003;//16��Ƶ  5M 
    MCF_ADC_POWER=0x00a4;
    MCF_ADC_CAL=0x0000;
    MCF_GPIO_PANPAR=0xFF;//ʹ��AN�ĵ�һ����
    MCF_ADC_CTRL1&=0xBFFF;//��ֹͣ0λ
    while(MCF_ADC_POWER&MCF_ADC_POWER_PSTS0)
    {
    	
    }
    while(MCF_ADC_POWER&MCF_ADC_POWER_PSTS1)
    {
    	
    }

    MCF_ADC_CTRL1|=0x2000;//��ʼ����
}
				                                     
void speed_measure_init(void)//�������жϳ�ʼ�������������ʼ��
{
    MCF_GPIO_PTAPAR|=MCF_GPIO_PTAPAR_ICOC2_ICOC2;//�������Ź��ܶ�ʱͨ��2
    MCF_GPT_GPTCTL2|=MCF_GPT_GPTCTL2_EDG2A;		// �����ز�׽
    MCF_GPT_GPTIE|=MCF_GPT_GPTIE_CI2;			// �ж�ʹ��
   
    MCF_INTC0_ICR46=0x3f;//�˴����ȼ��ɸ�����Ҫ�������ã���
  
    MCF_PIT0_PCSR|=MCF_PIT_PCSR_PRE(0x3);//previous:0x3
    MCF_PIT0_PMR=0x1388;//��ʱ������ֵΪ5000����ʱʱ��Ϊ1ms��
    MCF_PIT0_PCSR|=MCF_PIT_PCSR_RLD;//��ʱ��0��ʼ������,����λ��
    MCF_INTC0_ICR55=0x2f;//�˴����ȼ��ɸ�����Ҫ�������ã�����
    MCF_GPIO_PTAPAR|=MCF_GPIO_PTAPAR_ICOC3_ICOC3;//���ö�ʱͨ��3
    MCF_GPT_GPTPACTL|=MCF_GPT_GPTPACTL_PAE;//ʹ���������
    MCF_GPT_GPTPACNT=0;			//��ʼ�����������Ϊ0
    MCF_PIT0_PCSR|=MCF_PIT_PCSR_PIE;   //�����ۼ�����ʼ����
    EnableInterrupts;  //ȥ��SR�ж�����
    MCF_INTC0_IMRH&=~MCF_INTC_IMRH_INT_MASK46;
    MCF_INTC0_IMRH&=~MCF_INTC_IMRH_INT_MASK55;
    MCF_INTC0_IMRL&=~MCF_INTC_IMRL_MASKALL;
}

__declspec(interrupt)
void Pluse_Catch()
{
	count++;
	MCF_GPT_GPTFLG1|=MCF_GPT_GPTFLG1_CF2; 
}

void CheckCarStand(void) 
{
	static uint8 beepcount = 0;
	int i;
			if((Gpio_right == 0)&&(L_flag == 0))
			{
				Dly_ms(40);
				if(Gpio_right == 0)
				{
					L_flag = 1;
					beep();	
				}
				while(Gpio_right == 0)
				{
				;
				}	
			}
	if((g_fCarAngle>MAXERRANGLE)||(g_fCarAngle<MINERRANGLE)||(g_LoseLineFlag == 1)) 
	 {
	   	    g_ntempcount=0;
			beepcount++;
			if(beepcount == 1)
			{
				LCD_Init(); 
				LCD_Fill(0x00);
				displaytime(g_timecount);
				LCD_P6x8Str(0,0,"Spd_Int:");
    			display_num5bits(49,0 ,(int16)(g_fSpeedControlIntegral));
     			CarControlStop();
     			beep();
     			L_flag = 0;
     			g_fSpeedControlIntegral = 0;
     			g_fSpeedControlIntegral_rec = 0;
					LCD_P8x16Str(0,6,"pressRight2Go");
				if((g_fCarAngle>MAXERRANGLE)||(g_fCarAngle<MINERRANGLE))
					LCD_P8x16Str(10,4,"angle wrong");
				if((g_LoseLineFlag == 1))
					LCD_P6x8Str(10,1,"loseline");
			}
			else if(beepcount >200)
			{
				beepcount = 200;
			}
			return;
		}
		else  
		{
			if(g_BeepEnableFlag)
			{
				if(g_nCurveFlag>0)//�������������ж�
				MCF_GPIO_PORTNQ |= MCF_GPIO_PORTNQ_PORTNQ1;
				else 
				MCF_GPIO_PORTNQ &= ~MCF_GPIO_PORTNQ_PORTNQ1;
			}
			if(beepcount>0)
			{
				g_timecount = 0;
				g_StartCount = 0;
				g_fSPEED_CONTROL_P_temp = g_fSPEED_CONTROL_P;
				for(i = 0;i<Tran_Bytenum;i++)
				{
					send[i] = 0;
				}
				for(i = 0;i<20;i++)
				{
					g_fSpeedControlOut_rec[i] = 0; 
				}
			}
			beepcount = 0;
			if(L_flag == 1)
			{
				CarControlStart();	
			}
		}
}

void CarControlStop(void) 
{
	g_fLeftMotorOut=0;
	g_fRightMotorOut=0;
	g_nAngleControlFlag = 0;
	g_nSpeedControlFlag = 0;
	g_nDirectionControlFlag =0;
}

void CarControlStart(void)
{
	LCD_Fill(0x00);
	g_nAngleControlFlag = 1;
	g_nSpeedControlFlag = 1;
	g_nDirectionControlFlag = 1;
}


void traceanalyze()//���������������ٶȿ���
{
	static int32 l_fErr = 0;
	static int l_TraceCount = 0;
	static int32 g_nganalysis=0;
	static uint16 gcheck=0;
	
	
	g_ntempcount++;
	l_fErr += g_fLeftRightSub;
	l_TraceCount++;

	if(l_TraceCount >= 30)
	{
			//�ж�ƫ���С
			l_fErr/=30;

			if((l_fErr > errmin )&& (l_fErr < errmax))//ֱ��
			{
			    if(g_nCurveFlag>0)
				g_nCurveFlag--;
			}
			else 								//���
			{
					if(g_nCurveFlag < 3)
					g_nCurveFlag++;
			}
			l_TraceCount = 0;
			l_fErr = 0;
			
			/*if(g_nCurveFlag<=0)
			{
				if(g_nCarSpeedSet<g_nCarSpeedSet_temp+2)
				{
					g_nCarSpeedSet+=0.3;	
				}
			}
			else 
			{
				if(g_nCarSpeedSet>g_nCarSpeedSet_temp)
				{
					g_nCarSpeedSet-=0.1;
				}
			}*/
		/*	if((g_StraitEnableFlag)&&((g_timecount/1000) > g_StraightAddTime)&&(g_nCurveFlag <= 0))//����һ��ʱ�䷧ֵ
			{
				gcheck++;
				if(gcheck >= (g_AddSpdPeriod*10))
				{
					gcheck = 0;
					if(g_nCarSpeedSet < 45)
					g_nCarSpeedSet++ ;	
				}
				
			}
			else if((g_StraitEnableFlag)&&((g_timecount/1000) > g_StraightAddTime)&&(g_nCurveFlag > 0))
			{
				gcheck++;
				if(gcheck >= (g_AddSpdPeriod*10))
				{
					gcheck = 0;
					if(g_nCarSpeedSet > 26)
					g_nCarSpeedSet-- ;	
				}
			}
			
				if((g_StraitEnableFlag)&&(g_nCurveFlag <= 0))//��������·�̷�ֵ
			{
				gcheck++;
				if(gcheck >= (g_AddSpdPeriod2*1000))
				{
					gcheck -= g_AddSpdPeriod*10;
					if(g_nCarSpeedSet < 45)
					g_nCarSpeedSet++ ;	
				}
				
			}
			else if((g_StraitEnableFlag)&&(g_nCurveFlag > 0))
			{
				gcheck++;
				if(gcheck >= (g_AddSpdPeriod2*1000))
				{
					gcheck -= g_AddSpdPeriod*10;;
					if(g_nCarSpeedSet > 26)
					g_nCarSpeedSet-- ;	
				}
			}*/
	}

}

void beep(void)
{
	BEEP_ON;
	Dly_ms(40);
	BEEP_OFF;
}

void displaytime(uint32 time)
{
	char ch[7];
	if(time >=99999 )//��ʱ��������99s
	time = 99999;	
	ch[0] = (char)((time/10000)%10 + '0');
	ch[1] = (char)((time/1000)%10 + '0');
	ch[3] = (char)((time/100)%10 + '0');
	ch[2] = '.';
	ch[4] = (char)((time/10)%10 + '0');
	ch[5] = (char)((time/1)%10 + '0');
	ch[6] = '\0';
	LCD_P8x16Str(10,2,ch);
}

void display_num5bits(char a,char b ,int16 num)
{
	char ch[7];
	if(num < 0)
	{
		num = (short)(-num);
		ch[0] = '-';
	}
	else 
	{
		ch[0] = ' '; 
	}
	if(num >=32768 )//����������ʾ32768
	num = (short)32768;	
	ch[1] = (char)((num/10000)%10 + '0');
	ch[2] = (char)((num/1000)%10 + '0');
	ch[3] = (char)((num/100)%10 + '0');
	ch[4] = (char)((num/10)%10 + '0');
	ch[5] = (char)((num/1)%10 + '0');
	ch[6] = '\0';
	LCD_P6x8Str(a,b,ch);
}
void somesets(void)
{
	uint32 i,k;
	char ch[3],j; 
	char keycheck;
	if((Gpio_right == 0)&&(L_flag == 1))//�Ҽ���ʾ��¼ƫ��
	{
		Dly_ms(20);
		if(Gpio_right == 0)
		{
			MCF_PIT0_PCSR &= ~MCF_PIT_PCSR_EN; //�ر�PIT0
		/*	for(i=0;i<RECORD_PAGENUM*24;i++) //���Լ�¼�Ƿ�����
			{
				g_err_rec[i] = i;
			}*/
     		i = 0;
     		LCD_Fill(0x00);
     		while(Gpio_undo != 0)//ȡ�����˳���ʾ
     		{
     			if(Gpio_up == 0)
     			{
     			    Dly_ms(20);
     				if(Gpio_up == 0)
     				{
     					if(i>0)
     					i--;	
     				}
     				while(Gpio_up == 0)
     				{
     					;
     				}
     			}
     			if(Gpio_down == 0)
     			{
     				Dly_ms(20);
     				if(Gpio_down == 0)
     				{
     					if(i<RECORD_PAGENUM-1)
     					i++;
     				}
     				while(Gpio_down == 0)
     				{
     					;
     				}
     			}
     			ch[0] = (char)(i/10 + '0');
     			ch[1] = (char)(i%10 + '0'); 
     			ch[2] = '\0';
     			LCD_P6x8Str(0,0,ch);
     			k = i*24;
     			for(j=0;j<8;j++)
     			{
     				display_num5bits(12,j ,(int16)(g_err_rec[k]));
     				k++;
     			}
     			for(j=0;j<8;j++)
     			{
     				display_num5bits(50,j ,(int16)(g_err_rec[k]));
     				k++;
     			}
     			for(j=0;j<8;j++)
     			{
     				display_num5bits(88,j ,(int16)(g_err_rec[k]));
     				k++;
     			}
     		}
     		LCD_Fill(0x00);
     		LCD_P8x16Str(30,3,"Running...");
     		MCF_PIT0_PCSR|=MCF_PIT_PCSR_EN; //PIT0ʹ��
     		g_ntempcount = 0;	
		}
	}
		if(Gpio_left == 0)//������봫��������
     	{
     		i = 0;
     		LCD_Fill(0x00);
     		while(Gpio_undo != 0)//ȡ�����˳�����
     		{
     			i++;
     			if(i>80000)
     			{
     				LCD_P6x8Str(0,0,"L&R_Sub:");
     				display_num5bits(49,0 ,(int16)(g_fLeftRightSub));
     				LCD_P6x8Str(0,1,"L&R_Add:");
     				display_num5bits(49,1 ,(int16)(g_fLeftRightAdd1));
     				LCD_P6x8Str(0,2,"Vol_lft:");
     				display_num5bits(49,2 ,(int16)(VOLTAGE_LEFT));
     				LCD_P6x8Str(0,3,"Vol_Rgt:");
     				display_num5bits(49,3 ,(int16)(VOLTAGE_RIGHT));
     				LCD_P6x8Str(0,4,"L_ORG:");
     				display_num5bits(49,4 ,(int16)(VOLTAGE_LEFT_ORG));
     				LCD_P6x8Str(0,5,"R_ORG:");
     				display_num5bits(49,5 ,(int16)(VOLTAGE_RIGHT_ORG));
     				LCD_P6x8Str(0,6,"CarSpd:");
     				display_num5bits(49,6 ,(int16)(g_fCarSpeed));
     				LCD_P6x8Str(0,7,"GY_ORG:");
     				display_num5bits(49,7 ,(int16)(GYR_ORG));
     				i = 0;
     				if(Gpio_right == 0)//���Ҽ��л�����һ��
     				{
     					i = 0;
     					LCD_Fill(0x00);
     					while(Gpio_undo != 0)//���ص���һ��
     					{
     							i++;
     						if(i>80000)
     						{
     							LCD_P6x8Str(0,0,"Angle  :");
     							display_num5bits(49,0 ,(int16)(g_fCarAngle));
     							LCD_P6x8Str(0,2,"Or_Ang :");
     							display_num5bits(49,2 ,(int16)(g_foriginal_angle));
     							LCD_P6x8Str(0,4,"Ag_Rate:");
     							display_num5bits(49,4 ,(int16)(g_foriginal_anglerate));
     							LCD_P6x8Str(0,5,"Z_angle:");
     							display_num5bits(49,5 ,(int16)(ACC_ORG));
     							LCD_P6x8Str(0,7,"Dr_Rate:");
     							display_num5bits(49,7 ,(int16)((g_nInputVoltage[7]-g_fgyroscopestandard1)*0.172));
     							i = 0;
     						}
     					}
     					while(Gpio_undo == 0)
     					{
     						;
     					}
       					LCD_Fill(0x00);   					
     				}

     			}
     		}
     		LCD_Fill(0x00);
     		LCD_P8x16Str(30,3,"Running...");
     		g_ntempcount = 0;
     	}
     	
     	if(Gpio_down == 0)//�¼�����ǳ��ò�������
     	{
     		Dly_ms(20);//��������
     		while(Gpio_down == 0)
     		{
     			;
     		}
			while(Gpio_confirm!=0)//���������ʹ��
			{
	
				if(Gpio_up == 0)
				{
					LCD_Fill(0x00);
					g_BeepEnableFlag = 1;
					LCD_P8x16Str(5,3,"BeepEnable");
					LCD_P8x16Str(5,5,"Up or Down");
					while(Gpio_up == 0)
					{
						;
					}
				}
				if(Gpio_down == 0)
				{
					LCD_Fill(0x00);
					g_BeepEnableFlag = 0;
					LCD_P8x16Str(5,3,"BeepDisable");
					LCD_P8x16Str(5,5,"Up or Down");
					while(Gpio_down == 0)
					{
						;
					}
				}
		
			}
			Dly_ms(20);
			while(Gpio_confirm == 0)
			{
				;
			}
			/*LCD_Fill(0x00);
     		LCD_P8x16Str(5,3,"Straight?");//ֱ���Ƿ���ʹ��
			LCD_P8x16Str(5,5,"Up or Down");
			while(Gpio_confirm!=0)
			{
	
				if(Gpio_up == 0)
				{
					LCD_Fill(0x00);
					g_StraitEnableFlag = 1;
					LCD_P8x16Str(5,3,"StraightEnable");
					LCD_P8x16Str(5,5,"Up or Down");
					while(Gpio_up == 0)
					{
						;
					}
				}
				if(Gpio_down == 0)
				{
					LCD_Fill(0x00);
					g_StraitEnableFlag = 0;
					LCD_P8x16Str(5,3,"StraightDisable");
					LCD_P8x16Str(5,5,"Up or Down");
					while(Gpio_down == 0)
					{
						;
					}
				}
		
			}
			Dly_ms(20);
			while(Gpio_confirm == 0)
			{
				;
			}*/
			LCD_Fill(0x00);
     		LCD_P8x16Str(5,3,"Curve_Int?");//����Ƿ�����趨
			LCD_P8x16Str(5,5,"Up or Down");
			while(Gpio_confirm!=0)
			{
	
				if(Gpio_up == 0)
				{
					LCD_Fill(0x00);
					g_CurveIntFlag = 1;
					LCD_P8x16Str(5,3,"CurveIntEnable");
					LCD_P8x16Str(5,5,"Up or Down");
					while(Gpio_up == 0)
					{
						;
					}
				}
				if(Gpio_down == 0)
				{
					LCD_Fill(0x00);
					g_CurveIntFlag = 0;
					LCD_P8x16Str(5,3,"CurveIntDisable");
					LCD_P8x16Str(5,5,"Up or Down");
					while(Gpio_down == 0)
					{
						;
					}
				}
		
			}
			Dly_ms(20);
			while(Gpio_confirm == 0)
			{
				;
			}
			LCD_Fill(0x00);
     		LCD_P8x16Str(5,3,"DIR_D_SEL");//ת��D����ѡ��
			LCD_P8x16Str(5,5,"Up or Down");
			while(Gpio_confirm!=0)
			{
	
				if(Gpio_up == 0)
				{
					LCD_Fill(0x00);
					g_nDirection_Selflag = 1;
					LCD_P8x16Str(5,3,"ELE");
					LCD_P8x16Str(5,5,"Up or Down");
					while(Gpio_up == 0)
					{
						;
					}
				}
				if(Gpio_down == 0)
				{
					LCD_Fill(0x00);
					g_nDirection_Selflag = 0;
					LCD_P8x16Str(5,3,"GRY");
					LCD_P8x16Str(5,5,"Up or Down");
					while(Gpio_down == 0)
					{
						;
					}
				}
		
			}
			Dly_ms(20);
			while(Gpio_confirm == 0)
			{
				;
			}
			LCD_Fill(0x00);
     		LCD_P8x16Str(5,1,"ACC_ZERO");//���ٶȼ��������
			LCD_P8x16Str(5,5,"Up or Down");
			while(Gpio_confirm!=0)
			{
				display_num5bits(5,3,g_fanglezstandard);
				if(Gpio_up == 0)
				{
					g_fanglezstandard += 10;
					display_num5bits(5,3,g_fanglezstandard);
					LCD_P8x16Str(5,5,"Up or Down");
					Dly_ms(40);
					while(Gpio_up == 0)
					{
						;
					}
					Dly_ms(40);
				}
				if(Gpio_down == 0)
				{
					g_fanglezstandard -= 10;
					display_num5bits(5,3,g_fanglezstandard);
					LCD_P8x16Str(5,5,"Up or Down");
					Dly_ms(40);
					while(Gpio_down == 0)
					{
						;
					}
					Dly_ms(40);
				}
		
			}
			Dly_ms(20);
			while(Gpio_confirm == 0)
			{
				;
			}
			LCD_Fill(0x00);
     		LCD_P8x16Str(30,3,"Running...");
     		g_ntempcount = 0;
     	}
     	
     	
		if(Gpio_confirm == 0)
		{
		 //frame1( );
		    MCF_PIT0_PCSR &= ~MCF_PIT_PCSR_EN; //�ر�PIT0
		 	LCD_Init();
			Dly_ms(40);
			
			while(keycheck == 0)//�ȴ�����̧��
			{
				keycheck= Gpio_up
          				 &&Gpio_down
          				 &&Gpio_left
          				 &&Gpio_right
         				  &&Gpio_confirm
         				  &&Gpio_undo;	
			}
			
		g_ckeyvalue=0;
  		while(g_ckeyvalue!=0x20)
  		{
    
  			frame8( );       //��ʾ�����Խ���
    		g_ckeyvalue=0;
   			if(g_cmeumselectnew==0)
      			frame2( );   //����ѡ����棬ѡ�нǶ�
    			else if(g_cmeumselectnew==1)
      			frame3( );   //����ѡ����棬ѡ���ٶ�
    			else
       			frame4( );    //����ѡ����棬ѡ�з���  
  			while((g_ckeyvalue!=0x10)&&(g_ckeyvalue!=0x20))
   			{
     			Keyscan();
    			if((g_ckeyvalue==0x01)&&(g_cmeumselectnew!=0)) 
       			g_cmeumselectnew--; 
    			else if((g_ckeyvalue==0x01)&&(g_cmeumselectnew == 0))
    			g_cmeumselectnew = 2;
    			else if((g_ckeyvalue==0x02)&&(g_cmeumselectnew!=2))
       			g_cmeumselectnew++;
    			else if((g_ckeyvalue==0x02)&&(g_cmeumselectnew == 2))
				g_cmeumselectnew = 0;
    			if(g_cmeumselectnew==0)
      			frame2( );   //����ѡ����棬ѡ�нǶ�
    			else if(g_cmeumselectnew==1)
      			frame3( );   //����ѡ����棬ѡ���ٶ�
    			else
       			frame4( );    //����ѡ����棬ѡ�з���  
   			}
    
   			if(g_ckeyvalue==0x10)
  			{
   				switch(g_cmeumselectnew)
      			{
     				case 0:A_parameter_adjust();
    				break;
    				case 1:S_parameter_adjust();
    				break;
    				case 2:D_parameter_adjust();
      			}  
   			} 			
           	  	
		}
  		  LCD_Fill(0x00);
		  LCD_P8x16Str(5,3,"SelfCheck?");
   		  g_ckeyvalue=0;
   		  Keyscan();	
   		 if(g_ckeyvalue==0x10)
   		 {
   		    LCD_Fill(0x00);
        	LCD_P8x16Str(5,3,"g_selfcheck up");
   			 while(g_ckeyvalue!=0x01)//up
   			 {
    			Keyscan();
    		 }
    		Dly_ms(500);
    		beep();
   		 //���������У��
    		g_fgyroscopestandard = 0; 
    		g_fgyroscopestandard1 = 0; 
    		g_nADresult = 0;
			for(i=0;i<200;i++)
			{
	 			ADonce(2);
      			g_fgyroscopestandard+=g_nADresult;
      			ADonce(7);
      			g_fgyroscopestandard1+=g_nADresult;
			}
			g_fgyroscopestandard=g_fgyroscopestandard/200;
			g_fgyroscopestandard1=g_fgyroscopestandard1/200;
			beep();	
   	   	}
   	   	
   	   	while(Gpio_undo ==0)
   	   	{
   	   		;
   	   	}
   	   		 LCD_Fill(0x00);
		  	 LCD_P8x16Str(5,3,"StartSet?");	
         
       	while((Gpio_undo !=0)&&(Gpio_confirm != 0))
   	  	{	;}
   	   	if(Gpio_confirm == 0)
   	   	{
   	   		Dly_ms(20);
   	   	 
   	   		while(Gpio_confirm ==0)
   	   		{
   	   		;
   	   		}
   	   		LCD_Fill(0x00);
		  	LCD_P8x16Str(5,1,"StartSpeed");
   	   		g_nStartSpeed = (short)set2bits(g_nStartSpeed);
   	   		LCD_Fill(0x00);
		  	LCD_P8x16Str(5,1,"StartTime");
   	   		g_nStartTime = (short)set2bits(g_nStartTime);
   	   		LCD_Fill(0x00);
		  	LCD_P8x16Str(5,1,"SpdMax_Int*100");
   	   		g_nSpeedMax_Int = (float)(set5bitsnum(5,3,g_nSpeedMax_Int*100.0)/100.0);

   	   	}     
  
  
  		LCD_Fill(0x00);   
  		frame9( );
  		MCF_PIT0_PCSR|=MCF_PIT_PCSR_EN; //PIT0ʹ��
  		g_ntempcount = 0;	   
	}

	if(Gpio_up == 0)
	{
	Dly_ms(20);
	while(Gpio_up == 0)
	{
		;
	}
	LCD_Fill(0x00);
	LCD_P8x16Str(5,1,"Choice undo");
	while(Gpio_undo != 0)
	{
		if(Gpio_up == 0)
		{
			Dly_ms(20);
			while(Gpio_up == 0)
			{
				;
			}
		LCD_Fill(0x00);
		LCD_P8x16Str(5,1,"First");
		g_fSPEED_CONTROL_P = 0.85;//�ٶ�P����
  		g_fSPEED_CONTROL_I = 0.0468;//�ٶ�I����
    	g_ANGLE_CONTROL_P = 0.2089;//0.26	//�Ƕ�P����			
 		g_ANGLE_CONTROL_D = 0.0072;//0.00345//�Ƕ�D����
 		g_ANGLE_CONTROL_I = 0.00000;//�Ƕ�I����
 		g_fDIRECTION_CONTROL_P = 0.0568;//����P����
 		g_fDIRECTION_CONTROL_D = 0.5400;
 		g_fDIRECTION_CONTROL_I = 0.0;
 	    g_nStartSpeed = 40;
    	g_nStartTime = 8;
    	g_nSpeedMax_Int = 50;
    	g_nCarSpeedSet = 26;
		}
		if(Gpio_down == 0)
		{
			Dly_ms(20);
			while(Gpio_down == 0)
			{
				;
			}
		LCD_Fill(0x00);
		LCD_P8x16Str(5,1,"Second");
		g_fSPEED_CONTROL_P = 0.85;//�ٶ�P����
  		g_fSPEED_CONTROL_I = 0.0468;//�ٶ�I����
    	g_ANGLE_CONTROL_P = 0.2089;//0.26	//�Ƕ�P����			
 		g_ANGLE_CONTROL_D = 0.0072;//0.00345//�Ƕ�D����
 		g_ANGLE_CONTROL_I = 0.00000;//�Ƕ�I����
 		g_fDIRECTION_CONTROL_P = 0.0568;//����P����
 		g_fDIRECTION_CONTROL_D = 0.4500;
 		g_fDIRECTION_CONTROL_I = 0.0;
 	    g_nStartSpeed = 40;
    	g_nStartTime = 8;
    	g_nSpeedMax_Int = 50;
    	g_nCarSpeedSet = 24;	
		}
		if(Gpio_left == 0)
		{
			Dly_ms(20);
			while(Gpio_left == 0)
			{
				;
			}
		LCD_Fill(0x00);
		LCD_P8x16Str(5,1,"Back");
		g_fSPEED_CONTROL_P = 0.85;//�ٶ�P����
  		g_fSPEED_CONTROL_I = 0.0468;//�ٶ�I����
    	g_ANGLE_CONTROL_P = 0.2089;//0.26	//�Ƕ�P����			
 		g_ANGLE_CONTROL_D = 0.0072;//0.00345//�Ƕ�D����
 		g_ANGLE_CONTROL_I = 0.00000;//�Ƕ�I����
 		g_fDIRECTION_CONTROL_P = 0.0568;//����P����
 		g_fDIRECTION_CONTROL_D = 0.4500;
 		g_fDIRECTION_CONTROL_I = 0.0;
 	    g_nStartSpeed = 0;
    	g_nStartTime = 8;
    	g_nSpeedMax_Int = 40;
    	g_nCarSpeedSet = 24;	
		}
	}
		LCD_Fill(0x00);
     	LCD_P8x16Str(30,3,"Running...");
     	g_ntempcount = 0;
	}
}

void AD_all()
{
	char i,j;  
  	for(i=0;i<INPUT_VOLTAGE_AVERAGE;i++)
  	{
    	for(j = 0; j < 8;j++)
    	{
    		ADonce(j);			
        	g_lnInputVoltageSigma[j] += g_nADresult;	
    	}
        g_nInputVoltageCount++;    	
  	} 
  	GetInputVoltageAverage();   
}

void ADonce(uint16 ANn)
{
	
	while((MCF_ADC_ADSTAT&(1<<ANn))==0)
	{
		
	}
	g_nADresult=(int16)((MCF_ADC_ADRSLT(ANn)&0x7FF8)>>3);
}

void GetInputVoltageAverage(void) {
	int i;
	if(g_nInputVoltageCount == 0) {
		for(i = 0; i < 10; i++) 
			g_lnInputVoltageSigma[i] = 0;
		return;
	}
	for(i = 0; i < 10; i++) {
		g_nInputVoltage[i] = (uint16)(g_lnInputVoltageSigma[i] / g_nInputVoltageCount);
		g_lnInputVoltageSigma[i] = 0;	
	}
	g_nInputVoltageCount = 0;
}

void Angel_control()
{
	AngleCalculate_Complete();
	AngleControl();
}

void AngleCalculate_Complete(void) 
{
	float fDeltaValue;
	g_foriginal_anglerate=(float)((GYR_ORG-g_fgyroscopestandard)*0.332);//ԭʼ���ٶ�
	g_foriginal_angle=(ACC_ORG-g_fanglezstandard)*g_fangleratio;	//ԭʼ�Ƕ�
	g_fGyroscopeAngleSpeed =g_foriginal_anglerate; 
	g_fCarAngle = g_fGyroscopeAngleIntegral;
	fDeltaValue = (float)((g_foriginal_angle - g_fCarAngle) / GRAVITY_ADJUST_TIME_CONSTANT);
	g_fGyroscopeAngleIntegral += (g_fGyroscopeAngleSpeed +
				fDeltaValue) / GYROSCOPE_ANGLE_SIGMA_FREQUENCY;
}

void AngleControl(void) 
 {
	float fValue;
	if(g_nAngleControlFlag == 0) {
		g_fAngleControlOut = 0;
		return;
	}
	g_fCar_Angle_Set =  -g_fSpeedControlOut;/////////////ע�⼫��
	if(((int)g_nCarSpeedSet_temp == 6)||((int)g_nCarSpeedSet_temp == 5))//ֱ������,�������
	{
		g_fCar_Angle_Set = 0;
	}
    fValue = (float)((g_fCar_Angle_Set - g_fCarAngle) * g_ANGLE_CONTROL_P 
    					- g_fGyroscopeAngleSpeed * g_ANGLE_CONTROL_D*0.01);	         
	if(fValue > ANGLE_CONTROL_OUT_MAX)			fValue = ANGLE_CONTROL_OUT_MAX;
	else if(fValue < ANGLE_CONTROL_OUT_MIN) 	fValue = ANGLE_CONTROL_OUT_MIN;
	g_fAngleControlOut = fValue;	
}

void Speed_control()
{
	static uint16 L_speedcount = 0;
	L_speedcount++;
	g_nSpeedControlPeriod++;
	GetMotorPulse();
	if(L_speedcount>=SPEED_CONTROL_COUNT)//ƽ�ֵ�20����������
  	{
  		SpeedControl();//�������20ms����һ��
  		L_speedcount = 0;
  		g_nSpeedControlPeriod = 0;  
  	} 
  	SpeedControlOutput();
}

void GetMotorPulse()
 {
 	//#define jixing///////////////////////////////////////////////////////////////////
 	#ifndef jixing //��ǰ�����ж�
	    g_nLeftMotorPulseSigma += MCF_GPT_GPTPACNT;
		g_nRightMotorPulseSigma += count;	
		count = 0;
		MCF_GPT_GPTPACNT = 0;
	#else				//��ǰ�����ж�
		int left,right;
	    if(!MOTOR_LEFT_SPEED_POSITIVE)	
	      	left = -MCF_GPT_GPTPACNT;
	    else
	       left = MCF_GPT_GPTPACNT;
	    
	    if(!MOTOR_RIGHT_SPEED_POSITIVE)	
	    	right = -count;
	    else
	       right = count;
	    g_nLeftMotorPulseSigma += left;
		g_nRightMotorPulseSigma += right;
		count = 0;
		MCF_GPT_GPTPACNT = 0;
	#endif
  }
  
void SpeedControl(void) {
	float fP, fDelta,fDelta_temp;
	float fI,fD;
	static int L_tempcount = 0;
	static float g_fCarSpeed_old = 0;
	int i ;
	g_fCarSpeed = (g_nLeftMotorPulseSigma + g_nRightMotorPulseSigma) / 2;//�����ٶ�ƽ��Ϊ����
	g_nLeftMotorPulseSigma = g_nRightMotorPulseSigma = 0;//�����ٶ����� 
	g_fCarSpeed *= (CAR_SPEED_CONSTANT);
	if(g_StartCount < (g_nStartTime*1000))
	{
		fDelta = (float)((CAR_SPEED_SET - g_nStartSpeed)*g_StartCount/(g_nStartTime*1000.0) 
		+ g_nStartSpeed );//���ٶ�
		//g_fSPEED_CONTROL_P_temp = (float)(((g_StartCount/(g_nStartTime*1000.0)) + 1)*g_fSPEED_CONTROL_P);
	}
	else 
	{
		fDelta = CAR_SPEED_SET;
	}
	fDelta_temp = fDelta;
	fDelta -= g_fCarSpeed;//�����
	g_nSpeedMax_Int = (float)(fDelta); 
	if(g_nSpeedMax_Int<1)
	{
		g_nSpeedMax_Int = 1;
	}
	else if(g_nSpeedMax_Int>20)
	{
		g_nSpeedMax_Int = 20;
	}
	fP = fDelta * g_fSPEED_CONTROL_P;//����
//	fP = ((fDelta_temp-fDelta)/fDelta_temp + 1)*fP;
	fI = fDelta * g_fSPEED_CONTROL_I;//����
	fD = (g_fCarSpeed - g_fCarSpeed_old)*g_fSPEED_CONTROL_D;
	g_fSpeedControlIntegral += fI;//����
	if(g_StartCount < 3000)//��
		g_fSpeedControlIntegral=0;
	g_fSpeedControlOutOld = g_fSpeedControlOutNew;
	if((g_nCurveFlag > 0)&&(g_CurveIntFlag == 0))
	{
		g_fSpeedControlIntegral = g_fSpeedControlIntegral_rec;
	}
	if(g_fSpeedControlIntegral > SPEED_CONTROL_OUT_MAX)	
		g_fSpeedControlIntegral = (float)SPEED_CONTROL_OUT_MAX;
	else if(g_fSpeedControlIntegral < SPEED_CONTROL_OUT_MIN)  	
		g_fSpeedControlIntegral = (float)SPEED_CONTROL_OUT_MIN;	
	g_fSpeedControlIntegral_rec =	g_fSpeedControlIntegral;//��¼
	g_fSpeedControlOutNew = fP + g_fSpeedControlIntegral + fD;
	g_fSpeedControlOutNew = (float)(0.3*g_fSpeedControlOutNew + g_fSpeedControlOutOld*0.7);
	/*for(i = 9;i>0;i--)
	{
		g_fSpeedControlOut_rec[i] = g_fSpeedControlOut_rec[i-1];
		g_fSpeedControlOut_rec[0] = g_fSpeedControlOutNew;
	}
	for(i = 0;i<10;i++)
	{
		g_fSpeedControlOutNew+=g_fSpeedControlOut_rec[i];
	}
	g_fSpeedControlOutNew/=10;*/
	/*if((g_nCurveFlag>0)&&((g_fSpeedControlOutNew>g_fSpeedControlOutOld))&&(g_fSpeedControlOutOld>=7)&&(g_fCarSpeed >= 24))
	{
		g_fSpeedControlOutNew = g_fSpeedControlOutOld;
		L_tempcount = 50;
	}
	else 
	{
		if(L_tempcount>=0)
		{
			L_tempcount--;
			if((g_fSpeedControlOutNew - g_fSpeedControlOutOld)>=1)
			{
				g_fSpeedControlOutNew = (float)(g_fSpeedControlOutOld + 1);
			}
		}
	}*/
	
	if(!((g_fCarAngle>MAXERRANGLE)||(g_fCarAngle<MINERRANGLE)||(g_LoseLineFlag == 1)||(L_flag == 0))) 
    {
    	for(i=(RECORD_PAGENUM*24-1);i>0;i--)
    	{
    		g_err_rec[i] = g_err_rec[i-1];
    	}
    	g_err_rec[0] = g_fCarSpeed;
    }
		if(g_nSpeedControlFlag == 0) 
		{				//ֹͣ����
			g_fSpeedControlOutOld = g_fSpeedControlOutNew = g_fSpeedControlOut = 0;
			g_fSpeedControlIntegral = 0;
			return;
		}
}
  
void SpeedControlOutput(void) 
{ //���ٶ�����仯��ƽ����20����������
	float fValue;
	fValue = g_fSpeedControlOutNew - g_fSpeedControlOutOld;
	g_fSpeedControlOut = fValue * (g_nSpeedControlPeriod + 1) / SPEED_CONTROL_PERIOD
	+ g_fSpeedControlOutOld;
	/*if((g_fSpeedControlOut>1.2*(CAR_SPEED_SET - g_fCarSpeed)))//&&(g_timecount>5000))
	{
		g_fSpeedControlOut = 1.2*(CAR_SPEED_SET - g_fCarSpeed);
	}*/
}


void Direction_control()
{
	static uint16 L_directioncount = 0;
	L_directioncount++;
	g_nDirectionControlPeriod++;
	DirectionVoltageSigma();
	if(L_directioncount >= DIRECTION_CONTROL_COUNT) 
	{//�������ƽ�ֵ���������
	 	DirectionControl();
	  	L_directioncount = 0;
	  	g_nDirectionControlPeriod = 0;
	}	
	DirectionControlOutput();
}

void DirectionVoltageSigma(void) {
	int nLeft, nRight;
    nLeft = VOLTAGE_LEFT;
    nRight = VOLTAGE_RIGHT;
	g_fLeftVoltageSigma1 += nLeft; 
	g_fRightVoltageSigma1 += nRight;
}

void DirectionControl(void) {
	float  fLeftRightSub1, fValue,fLeftRightSub2;
	int nLeft, nRight,nLeft1,nRight1;  
	nLeft = (int)(g_fLeftVoltageSigma1 / DIRECTION_CONTROL_COUNT);
	nRight = (int)(g_fRightVoltageSigma1 / DIRECTION_CONTROL_COUNT);
	nLeft1 = (int)(g_fLeftVoltageSigma2 / DIRECTION_CONTROL_COUNT);
	nRight1 = (int)(g_fRightVoltageSigma2 / DIRECTION_CONTROL_COUNT);
	g_nLoseflag = nLeft + nRight;
	g_fLeftVoltageSigma1 = 0;
	g_fRightVoltageSigma1 = 0;
	g_fLeftVoltageSigma2 = 0;
	g_fRightVoltageSigma2 = 0;
	fLeftRightSub1 = nLeft-nRight;
	fLeftRightSub2 = nLeft1-nRight1;
	//fLeftRightSub = (float)(fLeftRightSub1*0.0360 + fLeftRightSub2*0.0029);
	//fLeftRightSub*=37;//Ϊ������֮ǰ����
	g_fLeftRightAdd1 = nLeft + nRight;
	if(g_fLeftRightAdd1>50)
	{	
		g_fLeftRightSub1 = (float)fLeftRightSub1; 
		g_fLeftRightSub = ((float)g_fLeftRightSub1)/(float)g_fLeftRightAdd1*1000;
	}
   	g_fDirectionControlOutOld = g_fDirectionControlOutNew;
   	if(g_nDirection_Selflag)
   	{
   		fValue = (float)((g_fLeftRightSub*0.01) * g_fDIRECTION_CONTROL_P  + 
   		0.01*g_fDIRECTION_CONTROL_D*(g_fLeftRightSub - g_fLeftRightSub_old));	
   	}
   	else
   	{
   		fValue = (float)((g_fLeftRightSub*0.01) * g_fDIRECTION_CONTROL_P  - 
   		0.001*g_fDIRECTION_CONTROL_D*((g_nInputVoltage[2]-g_fgyroscopestandard1)*0.172));	
   	}

   	if(fValue > DIRECTION_CONTROL_OUT_MAX) fValue = DIRECTION_CONTROL_OUT_MAX;
   	if(fValue < DIRECTION_CONTROL_OUT_MIN) fValue = DIRECTION_CONTROL_OUT_MIN;
	g_fDirectionControlOutNew = fValue;   
    g_fLeftRightSub_old = g_fLeftRightSub;

	if((g_nDirectionControlFlag == 0)) {
		g_fDirectionControlOut = 0;
		g_fDirectionControlOutOld = g_fDirectionControlOutNew = 0;
		return;
	}
}

void DirectionControlOutput(void) {
	float fValue;
	fValue = g_fDirectionControlOutNew - g_fDirectionControlOutOld;
	g_fDirectionControlOut = fValue * (g_nDirectionControlPeriod + 1) / DIRECTION_CONTROL_PERIOD 
	+ g_fDirectionControlOutOld;	
}

void All_init()
{
	AD_init();
	PWM_init();//PWM��ʼ��
	CarSubInit();//ȫ�ֱ�����ʼ��
	MotorOutput(); //������
	speed_measure_init();//���ټ���ʱ�жϳ�ʼ��
	Spi_init();
	Portinit();	
    LCD_Init();  
}


void CRC16(unsigned char *Array,unsigned char *Rcvbuf,unsigned int Len)
{
	unsigned int IX,IY,CRC;
	CRC = 0xFFFF;
	if(Len <= 0)
	CRC = 0;
	else 
	{
		Len--;
		for(IX = 0;IX<=Len;IX++)
		{
			CRC=CRC^(unsigned int)(Array[IX]);
			for(IY = 0;IY<=7;IY++)
			if((CRC&1)!=0) CRC = (CRC>>1)^0xA001;
			else CRC = CRC>>1;
		}
	}
	Rcvbuf[0] = (unsigned char)((CRC&0xff00)>>8);
	Rcvbuf[1] = (unsigned char)(CRC&0x00ff);
}
/*5λ�����������ã�a,bΪ����ֵ��numΪ��Σ�����int*/
int set5bitsnum(char a,char b, int num)
{
	char bit[5];
	char temp_key = 0;
	char bit_now = 2;//��ʼ�����λ�ã��������
	char i;
	bit[0] = (char)(num%10);
	bit[1] = (char)((num%100)/10);
	bit[2] = (char)((num%1000)/100);
	bit[3] = (char)((num%10000)/1000);
	bit[4] = (char)((num%100000)/10000);
		for(i = 4;i>=0;i--)
		{
			displaynum((unsigned char)(a+(4-i)*8),b,bit[i]);
		}
		displaynum((unsigned char)(a+(4 - bit_now)*8),b,bit[bit_now]+11);
	while((temp_key !='b')&&(temp_key !='c'))
	{
		temp_key = Keyscan_s();
		switch(temp_key)
		{
			case 'u':
				if(bit[bit_now]<9)
				bit[bit_now]+=1;
				else bit[bit_now] = 0;
				break;
			case 'd':
				if(bit[bit_now]>0)
				bit[bit_now]-=1;
				else bit[bit_now] = 9;
				break;
			case 'l':
				if(bit_now<4)
					bit_now++;
				else 
					bit_now = 0;
				break;
			case 'r':
				if(bit_now>0)
					bit_now--;
				else 
					bit_now = 4;
				break;
			default:
				continue;
		}
		for(i = 4;i>=0;i--)
		{
			displaynum((unsigned char)(a+(4-i)*8),b,bit[i]);
		}
		displaynum((unsigned char)(a+(4 - bit_now)*8),b,bit[bit_now]+11);
	}
	return bit[4]*10000+bit[3]*1000+bit[2]*100+bit[1]*10+bit[0];	
}

#include"carsub.h"
#include"support_common.h"
__declspec(interrupt)
void On_PIT0interrupt()
{
    static int losecount = 0;
    MCF_GPIO_PORTTF |=MCF_GPIO_PORTTF_PORTTF3;//�̵�ʱ�����
    g_timecount++;
	if(g_StartCount < g_nStartTime*1000)
		g_StartCount++;
	if(g_nLoseflag <20)//����ͣ��
	{
		losecount++;
	}
	else losecount = 0;
	if(losecount >100)
	{
		if(((int)g_nCarSpeedSet_temp != 6)&&((int)g_nCarSpeedSet_temp != 7))//ֱ������
		{
			g_LoseLineFlag = 1;
		}
		else 
		{
			g_LoseLineFlag = 0;
		}
	}	
	else g_LoseLineFlag = 0;
	AD_all();//���������ݲɼ�������ƽ��ֵ
  	traceanalyze();//���������������ٶȿ���
	Angel_control();
	Direction_control();
	Speed_control();
  	if((int)g_nCarSpeedSet_temp != 4)//�ٶ�Ϊ4ʱ��Ϊ�ص����־	
    MotorOutput();
  	if(temp_rec == 0)
     	{
     		send[21] = (int8)0xf1;
     		send[20] = (uint8)(g_timecount>>8);
     		send[19] = (uint8)g_timecount;
     		send[18] = (int8)((int)VOLTAGE_LEFT>>8);
     		send[17] = (int8)VOLTAGE_LEFT;
     		send[16] = (int8)((int)VOLTAGE_RIGHT>>8);
     		send[15] = (int8)VOLTAGE_RIGHT;
     		send[14] = (int8)((int)(g_fSpeedControlOut*100)>>8);
     		send[13] = (int8)(g_fSpeedControlOut*100);
     		send[12] = (int8)((int)(g_fAngleControlOut*100)>>8);
     		send[11] = (int8)(g_fAngleControlOut*100);
			send[10] = (int8)((int)(g_fDirectionControlOut*100)>>8);
     		send[9] =(int8)(g_fDirectionControlOut*100);
     		send[8] = (int8)((int)(g_fLeftMotorOut*100)>>8);
     		send[7] =(int8)(g_fLeftMotorOut*100);
     		send[6] = (int8)((int)(g_fRightMotorOut*100)>>8);
     		send[5] =(int8)(g_fRightMotorOut*100);
     		send[4] = (int8)((int)(g_fCarAngle*100)>>8);
     		send[3] =(int8)(g_fCarAngle*100);
     		send[2] = (int8)((int)(g_fCarSpeed*100)>>8);
     		send[1] =(int8)(g_fCarSpeed*100);
     		send[0] = (int8)0xf2;
     		temp_rec = 1;
     	}
	MCF_GPIO_PORTTF &= ~MCF_GPIO_PORTTF_PORTTF3 ;//�̵�ʱ�����
	MCF_PIT0_PCSR|= MCF_PIT_PCSR_PIF;//���жϱ�־λ
}

