//һЩ���Ժ���
#ifndef __TEST_H
#define __TEST_H
//extern void write_date(int16 date,int16 *p);
//void send_date_topc(int16 *p);
#endif