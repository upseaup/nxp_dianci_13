/*********************************************************************************************************************
 * COPYRIGHT NOTICE
 * Copyright (c) 2017,逐飞科技
 * All rights reserved.
 * 技术讨论QQ群：179029047
 *
 * 以下所有内容版权均属逐飞科技所有，未经允许不得用于商业用途，
 * 欢迎各位使用并传播本程序，修改内容时必须保留逐飞科技的版权声明。
 *
 * @file       		MPU6050
 * @company	   		成都逐飞科技有限公司
 * @author     		逐飞科技(QQ3184284598)
 * @version    		v2.0
 * @Software 		IAR 7.7 or MDK 5.23
 * @Target core		S9KEA128AMLK
 * @Taobao   		https://seekfree.taobao.com/
 * @date       		2017-11-6
 * @note	
					L3G4200D接线定义
					------------------------------------ 
						SCL                 查看SEEKFREE_IIC文件内的SEEKFREE_SCL宏定义
						SDA                 查看SEEKFREE_IIC文件内的SEEKFREE_SDA宏定义
					------------------------------------ 
 ********************************************************************************************************************/


#include "include.h"
//硬件iic
#include "KEA128iic.h"
#include "SEEKFREE_MPU6050.h"
//#define  PRINTF 1     //定义打印，不定义不打印acc gyro 
int16 mpu_gyro_x,mpu_gyro_y,mpu_gyro_z;
int16 mpu_acc_x,mpu_acc_y,mpu_acc_z;



//-------------------------------------------------------------------------------------------------------------------
//  @brief      初始化MPU6050
//  @param      NULL
//  @return     void					
//  @since      v1.0
//  Sample usage:				调用该函数前，请先调用模拟IIC的初始化
//-------------------------------------------------------------------------------------------------------------------
void InitMPU6050(void)
{
     i2c_write_reg(i2c1,MPU6050_DEV_ADDR, PWR_MGMT_1, 0x00);	   //解除休眠状态
     i2c_write_reg(i2c1,MPU6050_DEV_ADDR, SMPLRT_DIV, 0x00);      // 0x07  125HZ采样率  0x00 1k采样率 根据手册这个是改变陀螺仪采样频率
     i2c_write_reg(i2c1,MPU6050_DEV_ADDR, CONFIG, 0x04);          // 之前是0x04 这个地方应该是设置陀螺仪数字低通滤波器的，当它是0或7的时候，采样频率最高8kmz(也是中国队及时报告提出问题)
     i2c_write_reg(i2c1,MPU6050_DEV_ADDR, GYRO_CONFIG, 0x18);     //2000   +-2000 这个地方应该是平衡小车之家备注错了，应该把1000改2000 根据手册才是除以16.4
     i2c_write_reg(i2c1,MPU6050_DEV_ADDR, ACCEL_CONFIG, 0x10);    //8g
     i2c_write_reg(i2c1,MPU6050_DEV_ADDR, User_Control, 0x00);
     i2c_write_reg(i2c1,MPU6050_DEV_ADDR, INT_PIN_CFG, 0x02);
  //  systick_delay_ms(50);
     //mpu6050_self_inspection();                                   //6050自检
}



//-------------------------------------------------------------------------------------------------------------------
//  @brief      获取MPU6050加速度计数据
//  @param      NULL
//  @return     void
//  @since      v1.0
//  Sample usage:				执行该函数后，直接查看对应的变量即可
//-------------------------------------------------------------------------------------------------------------------
void Get_AccData(void)
{
    uint8 dat[6];
    //simiic_read_regs(MPU6050_DEV_ADDR, ACCEL_XOUT_H, dat, 6, IIC);  
    i2c_read_reg_bytes(i2c1, MPU6050_DEV_ADDR, ACCEL_XOUT_H, 6,dat);
    mpu_acc_x = (int16)(((uint16)dat[0]<<8 | dat[1]))>>2;
    mpu_acc_y = (int16)(((uint16)dat[2]<<8 | dat[3]))>>2;
    mpu_acc_z = (int16)(((uint16)dat[4]<<8 | dat[5]))>>2;
}


//-------------------------------------------------------------------------------------------------------------------
//  @brief      获取MPU6050陀螺仪数据
//  @param      NULL
//  @return     void
//  @since      v1.0
//  Sample usage:				执行该函数后，直接查看对应的变量即可
//-------------------------------------------------------------------------------------------------------------------
void Get_Gyro(void)
{
    uint8 dat[6];
   // simiic_read_regs(MPU6050_DEV_ADDR, GYRO_XOUT_H, dat, 6, IIC);
      i2c_read_reg_bytes(i2c1, MPU6050_DEV_ADDR, GYRO_XOUT_H, 6,dat);
      mpu_gyro_x = (int16)(((uint16)dat[0]<<8 | dat[1]))>>3;
      mpu_gyro_y = (int16)(((uint16)dat[2]<<8 | dat[3]))>>3;
      mpu_gyro_z = (int16)(((uint16)dat[4]<<8 | dat[5]))>>3;
}
/*************************************************
 * 函数名称: mpu6050_self_inspection()
 * 输入参数: 
 * 输出参数: 
 *
 * 功    能: 当6050初始化失败时，重新初始化
 *
 * 作    者: 2018/5/22, by hawk2018
 *************************************************/
 void mpu6050_self_inspection(void)
 {
  if(mpu_acc_x==0&&mpu_acc_y==0&&mpu_acc_z==0
     &&mpu_gyro_x==0&&mpu_gyro_y==0&&mpu_gyro_z==0)
  {
    InitMPU6050();                                //如果失败 则继续嵌套
    OLED_P6x8Str(0,1,"6050 fault!");
  }
  else OLED_P6x8Str(0,1,"6050 ok!");
 }



