#include "include.h"
#include "control.h"	
#include "filter.h"

#include "data_pa.h"

/***************************************************************************
角度变为float 平衡性明显变好了，齿轮也不会响了，但是计算速度不知道慢了多少
角速度也改了，只改了y轴的
***************************************************************************/

/***************************************************************************/
#define P      3.1415  //PI被定义的精度太高了

/***************************************************************************/
extern 	int16 Balance_Pwm,Velocity_Pwm,Turn_Pwm;
extern  int16  mpu_gyro_x,mpu_gyro_y,mpu_gyro_z; //声明外部变量 在6050中定义
extern  int16  mpu_acc_x,mpu_acc_y,mpu_acc_z;    //声明外部变量 在6050中定义
extern  float  angle;                            //在filter中定义
extern  int16  Encoder_Left;                     //在kea128_it.c中定义
extern  int16  Encoder_Right;                    //在kea128_it.c中定义 
extern  int16  sum_encoder,sub_encoder;          //在kea128_it.c中定义 
extern volatile uint16 Flag_Target;              //在kea128_it.c中定义 
extern Change_Pid_Parameter pid_parmeter;        //pid参数
extern int16 sub_encoder_i;
extern float  E_I;                               //速度环积分
extern uint8 pc_flag;                            //在kea128_it.c中定义 


extern  int    Moto_L,Moto_R;                    //moto pwm分子
extern  uint8  uart_get;                                           //串口接收的数据，主要是停车用

extern Ad_Date ad_L1,ad_L2,ad_R1,ad_R2,ad_SL,ad_SR;          //电感采集的数据，定义在ad.c
extern Ad_Deal_position deal_position;           //处理位置结构体
extern Change_Race_Parameter   race_parmeter;    //赛道标志位


/**************************************************************************/
uint8 enter_flag;                              //进入圆环区域标志位
int16 assume_r;                               //用n来求曲率半径
int16 Gyro_Balance;                            //一下变量感觉不用float型 后期改
float  Angle_Balance;                          //看mpu_定义情况看int就可以  ,之前是int16,提高下精度
int16 Gyro_Turn;
int16 Acceleration_Z;
volatile uint8 state;
int16 Encoder_sum;
uint8 n_time;
int16 s_e0;
int16 s_e7;
int16 s_e0_old;
int16 s_e7_old;
int16 length;
int16 s_e7_add;
int16 s_e0_add;
uint8  poor_ra_sum_s;

uint8 R2_flag,L1_flag; 

//uint8 n;
int16 Encoder_d;
int16 Encoder_old;
int16 turn_s_;
float Accel_Y_old;
float Gyro_Y_old;
/**************************************************************************
函数功能：所有的控制代码都在这里面
         5ms定时中断由MPU6050的INT引脚触发
         严格保证采样和数据处理的时间同步，不是下面的定义				 
**************************************************************************/
void Get_Angle(void)
{ 
  static float Accel_Y,Gyro_Y;
   //DisableInterrupts;//关中断，保护采集数据
  Get_AccData();                                 //得到数据
  Get_Gyro();
  // EnableInterrupts;//开中断
  Gyro_Balance=-mpu_gyro_y;                                  //更新平衡角速度
  Accel_Y=atan2(mpu_acc_x,mpu_acc_z)*180/P;                 //计算倾角 ，倾角	//为什么不直接用mpu_acc_y,不应该是_y，应该改成zq(正前)
  Gyro_Y=mpu_gyro_y/16.4;                                    //陀螺仪量程转换，这个应该16.4应该和6050初始化G的设置有关
extern uint8 n;  
if(n!=1) {
  Accel_Y=(Accel_Y*8+Accel_Y_old*2)/10;
  Gyro_Y=(Gyro_Y*8+Gyro_Y_old*2)/10;
}
if(n==1) {
  Accel_Y=(Accel_Y*5+Accel_Y_old*5)/10;
  Gyro_Y=(Gyro_Y*5+Gyro_Y_old*5)/10;
}
  Kalman_Filter(Accel_Y,-Gyro_Y);//卡尔曼滤波	
 // Yijielvbo(Accel_Y,-Gyro_Y);     //一阶互补滤波
  Gyro_Y_old=Gyro_Y;
  Accel_Y_old=Accel_Y;
  Angle_Balance=angle;                                   //更新平衡倾角
  Gyro_Turn=mpu_gyro_z;                                      //更新转向角速度
  Acceleration_Z=mpu_acc_z;                                //===更新Z轴加速度计		
}
/**************************************************************************
函数功能：直立PD控制
入口参数：角度、角速度
返回  值：直立控制PWM
作    者：平衡小车之家
**************************************************************************/
//现在 1 ms进一次速度直立控制
int16 balance(float Angle,float Gyro)
{  
   float Bias;
   float fbd;
   int16 balance;
   fbd=pid_parmeter.bd/10;                  //因为小车的原因做小数点不好做，故除10代替，调的时候要注意

   Bias=Angle-ZHONGZHI+pid_parmeter.ad_angle;       //看中值，和机械角度有关，加6是为了让车跑
   //Bias=Angle-ZHONGZHI-(-pid_parmeter.ad_angle );
   //Bias=Angle-(ZHONGZHI-pid_parmeter.ad_angle ); 
   //Bias=Angle-ZHONGZHI;
   balance=(int32)(pid_parmeter.bp*Bias+Gyro*fbd);   //计算平衡的pwm  pd控制
   return balance;
}
/**************************************************************************
函数功能：速度PI控制 修改前进后退遥控速度，请修Target_Velocity，比如，改成60就比较慢了
入口参数：左轮编码器、右轮编码器
返回  值：速度控制PWM
作    者：平衡小车之家
**************************************************************************/
//之前车一直不能走的原因可能是速度环的控制周期太大了，不知道原理
//现在50ms进一次速度控制
//现在100ms进一次速度控制，以最下面的为准，重新算了下vp大概是-0.218
//改下vp再试试？
//12点51分 18年4/5
int16 velocity(int encoder_left,int encoder_right)
{  

  
#define I_MAX  20000   //速度环积分上限，相当于速度上限  //20000
      static float Velocity;
      static int16 Encoder_Least,Encoder
        ;//,Encoder_sub;
      static float Encoder_Integral;
      int16  Velocity_int,Movement;
      static float kp;                                                      //速度环周期100ms时最大kp在1.57左右，屏上为150
      float ki;                                                             //速度环周期 50ms时最大kp在3.33左右，屏上为33
      kp=((float)(pid_parmeter.vp))/10;                                     //因为小车的原因做小数点不好做，故除10代替，调的时候要注意
      //速度积分可以说p/200 但是当速度初值比较下时可能不能走 
      //如果改为p=1 i=20/1000 可以走 但是积分项太大会使车震荡（p=1 i=40/1000） 表现为车抬头减速在低头加速，如此反复
      //此时英加p或减小i
      ki=kp/200 ;//先调积分项 在改I_MAX                
      //ki=((float)(pid_parmeter.vi))/1000;                                
      sum_encoder=(Encoder_Left+Encoder_Right);
    
      Movement=pid_parmeter.bi;                                                          //给定一个速度  ,用bi指定速度
      //虽然目标速度改变在积分项对速度影响小 但是在积分项时变化太慢了
      //ki=kp/200 ki*I_MAX=kp*100 kp=1时 相当在p上改变v时的100 这里积分项还是用的双轮的编码器和
      
      //速度项在p 
      Encoder_Least =((sum_encoder)- Movement);                       //==获取最新速度偏差==测量数度（左右之和）
      //速度项在i
      // Encoder_Least =(float)((Encoder_Left+Encoder_Right- 0));                      

      Encoder *= 0.7;		                                            //===一节低通滤波器      
      Encoder += Encoder_Least*0.3;	                                    //===一节低通滤波器 
      Encoder_d=Encoder-Encoder_old;                                        //这里Encoder_old Encoder_d是全局变量 应该注意
      Encoder_old=Encoder;
      Velocity=Encoder*kp;   
      /////        //积分分离
       //if(absolute(Encoder)>=0.9*absolute(Movement)) 
       {
         //速度项在p
         Encoder_Integral +=Encoder;                                          
        //速度项在i
        // Encoder_Integral=Encoder_Integral-Movement;                          
 
      if(Encoder_Integral>I_MAX)  	Encoder_Integral=I_MAX;             //===积分限幅 15000/200=75   ，75太小  换300
      if(Encoder_Integral<-I_MAX)	Encoder_Integral=-I_MAX;            //===»积分限幅 用串级15000换75	
         E_I=Encoder_Integral*ki;
        Velocity+=E_I;   
       }                                       
      //===倾角过大 清除积分    
      if((Angle_Balance<-20)||(Angle_Balance>10))                   
      {
        Encoder_Integral=0;
      }  
      //论坛有说把积分项每20次清零，可以试试
      //不归位可能是I_MAX太小，改大试试
      /******
      * 速度环是有归位的，当周期是5ms,没有分20次加给电机是可以的 
      * 现在基本上是没有归为了   但是电机输出还是比较平稳的    5/22
      **********/
      //速度环限幅
      //必须有，但数值没调好
#define VELOCITY_MAX   400
//      if( Velocity>VELOCITY_MAX )
//      {
//        Velocity=VELOCITY_MAX;
//      }
//      if( Velocity<-VELOCITY_MAX )
//      {
//        Velocity=-VELOCITY_MAX;
//      }
       Velocity_int= (int32)Velocity;
      return  Velocity_int;
}

/*************************************************
* 函数名称: VelocityPWMOut()
* 输入参数: NewVelocityPWM_
* 输出参数: VelocityOUT
*
* 功    能: 速度变化量分20次 给电机
*           参考卓大大版本
* 作    者: 2018/5/22, by hawk2018
*************************************************/
int16 VelocityPWMOut(int16 NewVelocityPWM_ )
{
#define VelocityPERIODFAV (20)  
  static int16 NewVelocityPWM;
  static int16 LastVelocityPWM;
  static int16 PeriodCount=0;
  PeriodCount++;
  NewVelocityPWM=NewVelocityPWM_;
  int16  VelocityPWMfav ;
  int16  VelocityOUT ;
  VelocityPWMfav = NewVelocityPWM - LastVelocityPWM ;
  VelocityOUT = VelocityPWMfav *(PeriodCount)/VelocityPERIODFAV + LastVelocityPWM ;

  if(PeriodCount==20) 
  {
    PeriodCount=0;
    LastVelocityPWM= NewVelocityPWM;
  }
#define VelocityOUT_MAX  (-550)               //限制速度环输出最大值  可以考虑限制VelocityPWMfav（冠军车队好像限制VelocityPWMfav方案）
  if( VelocityOUT<VelocityOUT_MAX )
  {
    VelocityOUT=VelocityOUT_MAX;
  }

  return VelocityOUT ; 
}
/**************************************************************************
功    能 ；方向控制和转向控制 修改转向速度请修改turn_amplitude
入口参数 ；电磁信号，Z轴陀螺仪
返 回 值 ；转向PWM
周    期 ：？？
**************************************************************************/
uint8 tanency_flag=0;
int16 turn(float gyro)
{
#define TURN_MAX  300
      static int16 Turn;
      static int16  ess_now_absolute; 

      float Kp,Kd;
      static int16 ess_now,
      ess_old,ess_ess;                                              //电感误差
      static uint8 turn_a ;
      static uint8 flag_out;
      if( poor_ra_sum_s!=1 )
      { 
        turn_a=0;
       // flag_out=0;//DEFAULT;//这样会多清零好多次应该放在poor_ra_sum_s清零里 而且有错误 每次进if就清零了
      ess_now=deal_position.poor_ratio_sum;
      ess_now_absolute=absolute_int16( ess_now);                                   //取绝对值函数
      ess_ess=ess_now-ess_old;
//      ess_ess=ess_now+ess_old-2*ess_m;
//      ess_ess/=2;
      
//      0<absolute_int16(ess_now)<40 
//      这个地方可以有优化的，但是不一定用得到
      //按键改tp系列参数
//      pid_parmeter.tp_1=pid_parmeter.tp1;
//      pid_parmeter.tp_2=pid_parmeter.tp1;
//      pid_parmeter.tp_3=pid_parmeter.tp1;   
//      pid_parmeter.tp_4=pid_parmeter.tp1;
      //已经出现漏检了 应该把检测放到外面
                                                     //电感微分
//   {
//        if(ess_now_absolute<=5 )
//        {
//          Kp=((float)pid_parmeter.tp)/100;
//          Kd=((float)pid_parmeter.td)/10;
//        }
//        if((ess_now_absolute>5)&&(ess_now_absolute<=10) )
//        {
//          Kp=((float)pid_parmeter.tp_1)/100;
//          Kd=((float)pid_parmeter.td_1)/10;
//        }
//        if((ess_now_absolute>10)&&(ess_now_absolute<=20) )
//        {
//          Kp=((float)pid_parmeter.tp_2)/100;
//          Kd=((float)pid_parmeter.td_2)/10;
//        }
//        if((ess_now_absolute>20)&&(ess_now_absolute<=30) )
//        {
//          Kp=((float)pid_parmeter.tp_3)/100;
//          Kd=((float)pid_parmeter.td_3)/10;
//        }
//        if((ess_now_absolute>30)&&(ess_now_absolute<=40) )
//        {
//          Kp=((float)pid_parmeter.tp_4)/100;
//          Kd=((float)pid_parmeter.td_4)/10;
//        }
//      }
      Kp=((float)pid_parmeter.tp)/100;
      Kd=((float)pid_parmeter.td)/10;
      pid_parmeter.data_essP=ess_now*Kp;
      pid_parmeter.data_essD=ess_ess*Kd;
      pid_parmeter.data_essT=(pid_parmeter.data_essP+pid_parmeter.data_essD);
      Turn =(int16)( pid_parmeter.data_essT);
#define TURN_OUT_MAX (100)
        extern int16 assume_rr;
        if( 
           poor_ra_sum_s==4
             //|| sub_encoder_i>=assume_rr
               )
        {
//                  if(Turn> TURN_OUT_MAX)  Turn= TURN_OUT_MAX;
//                  if(Turn<-TURN_OUT_MAX)  Turn=-TURN_OUT_MAX;
          //Turn=Turn/5;
#define  OUT_P   (200)
        switch( flag_out )
        {
        case 0:
          break;
        case 1:{
          //if(Turn>0) Turn=Turn/5;  没有效果
          if(deal_position.SR_d>0);
            Turn=-OUT_P;
         // else if(assume_rr>-70) Turn=Turn/3;
        }
        break;      
        case 2:{
          //if(Turn<0) Turn=Turn/5;
          if(deal_position.SL_d>0);
            Turn=OUT_P;
          //else if(assume_rr>-70) Turn=Turn/3;
        }
        break;
        default:
          break;
        }

       }

//        if(Turn> TURN_MAX)  Turn= TURN_MAX;
//        if(Turn<-TURN_MAX)  Turn=-TURN_MAX;
   
//        ess_old=ess_m;
//        ess_m  =ess_now;
         ess_old=ess_now;
        
//        if(state==2)
//        {
//          Turn=Turn/2;
//        }
//        if(
//          // state==7||
//             state==8||state==9 )
//        {
//          Turn=Turn/5;
//          // buzzer_work_Mno(); 
//        }
        //else {buzzder_stop(); }

      }
      else if(poor_ra_sum_s==1)
      {
      ess_now=deal_position.poor_ratio_sum_s;       
      //ess_now=poor_ratio_sum_s();
      ess_now_absolute=absolute_int16( ess_now);                                   //取绝对值函数
      ess_ess=ess_now-ess_old;
//      ess_ess=ess_now+ess_old-2*ess_m;
//      ess_ess/=2;
      //Kp=((float)pid_parmeter.tp_s)/100;
      Kp=((float)pid_parmeter.tp_d)/100;
      Kd=((float)pid_parmeter.td_s)/10;                                                        //中间位置判断
      
        pid_parmeter.data_essP=ess_now*Kp;
        pid_parmeter.data_essD=ess_ess*Kd;
        pid_parmeter.data_essT=(pid_parmeter.data_essP+pid_parmeter.data_essD);
        Turn =(int16)( pid_parmeter.data_essT);

        ess_old=ess_now;
       
//        if(Turn>0&&Turn< 80)  Turn= 80;
//        if(Turn<0&&Turn>-80)  Turn=-80;        //打定角
      }

      if(Turn> TURN_MAX)  Turn= TURN_MAX;
      if(Turn<-TURN_MAX)  Turn=-TURN_MAX;
     // turn_old=Turn;
       if(turn_a<8)
       {
         turn_a++;
         turn_s_+=Turn;
#define R       (1)
#define L       (2)
#define DEFAULT (0)
         if(turn_a>=8) {
           if(Turn>0) flag_out=R;//{ R_flag=1;L_fag=0;}  //右园
           if(Turn<0) flag_out=L;//{ R_flag=0;L_fag=1;}  //左园
           //else       flag_out=DEFAULT;//{ R_flag=0;L_fag=0;} //如果有这句话 是个逻辑错误 初衷是好的
         }
       }

      return  Turn;

       
}
/*************************************************
* 函数名称: fuck()
* 输入参数: 
* 输出参数: 
*
* 功    能: 伪打定角
*
* 作    者: 2018/6/28, by hawk2018
*************************************************/
void fuck(void)
{

}
/*************************************************
* 函数名称: turn_c()
* 输入参数: 
* 输出参数: 
*
* 功    能: 处理入环
*
* 作    者: 2018/6/25, by hawk2018
*************************************************/
void turn_c(void)
{
 
}
/*************************************************
* 函数名称: out_c()
* 输入参数: 
* 输出参数: 
*
* 功    能: 出园R1flag 设置
*
* 作    者: 2018/6/27, by hawk2018
*************************************************/
void out_c(void)
{
 
}
/*************************************************
* 函数名称: turn_out()
* 输入参数: 
* 输出参数: 
*
* 功    能: 入圆后出园
*
* 作    者: 2018/6/26, by hawk2018
*************************************************/
void turn_out(void)
{


}
/*************************************************
* 名  字： TurnPWMOut()
* 输入量: Turn_pwm
* 输出量: Turn_pwm_control
*
* 作  用: 平滑控制输出
*
* ط    ֟: 2018/4/29, by hawk2018
*************************************************/

int16 TurnPWMOut(int16 NewTurnPWM_ )
{
#define TurnPERIODFAV (5)  
  static int16 NewTurnPWM;
  static int16 LastTurnPWM;
  static int16 PeriodCount=0;
  PeriodCount++;
  NewTurnPWM=NewTurnPWM_;
  int16  TurnPWMfav ;
  int16  TurnOUT ;
  TurnPWMfav = NewTurnPWM - LastTurnPWM ;
  TurnOUT = TurnPWMfav *(PeriodCount)/TurnPERIODFAV + LastTurnPWM ;

  if(PeriodCount==TurnPERIODFAV) 
  {
    PeriodCount=0;
    LastTurnPWM= NewTurnPWM;
  }
  return TurnOUT ; 
}
/*************************************************
* 函数名称: car_run()
* 输入参数: 
* 输出参数: 
*
* 功    能: 启动时速度太快会导致电池拖地 不能正常run  
*           启动后一段距离后（或时间）加速
*
* 作    者: 2018/7/2, by hawk2018
*************************************************/
//void car_run(void)
//{
//if( start_flag==0 &&sub_encoder_i<-20000)
//{
//  start_flag=1;
//  pid_parmeter.run=-350;
//}
//
//}
/*************************************************
* 函数名称: max_pwm()
* 输入参数: 
* 输出参数: 
*
* 功    能: 限制 pwm分子最大值
*
* 作    者: 2018/5/22, by hawk2018
*************************************************/
void max_pwm(void)
{
  if(Moto_L>0)
  {
   if(Moto_L>MOTO_MAX)
     {
      Moto_L=MOTO_MAX;
     }
  }
  else if(Moto_L<-MOTO_MAX)
  {
    Moto_L=-MOTO_MAX;
  }
  
    if(Moto_R>0)
  {
   if(Moto_R>MOTO_MAX)
     {
      Moto_R=MOTO_MAX;
     }
  }
  else if(Moto_R<-MOTO_MAX)
  {
    Moto_R=-MOTO_MAX;
  }
}
/*************************************************
* 函数名称: stop_car_ad()
* 输入参数: 
* 输出参数: 
*
* 功    能: 当出赛道时停车
*
* 作    者: 2018/5/9, by hawk2018
*************************************************/
extern uint8 start_flag;
extern int32 Velocity_Pwm_Conctrol;
extern uint8 ntime;
void stop_car(void)
{
  //uint16 three_sum;
  //three_sum=ad_L1.final+ad_R2.final+ad_R1.final;
  if(start_flag==1)
  {
    if(deal_position.three_sum<1)
    {
      Moto_R=0;
      Moto_L=0; 
    }
  }
  else 
  {
    if(deal_position.three_sum<1)
    {
    Moto_R=Balance_Pwm;
    Moto_L=Balance_Pwm;
    }
  }
  if((Angle_Balance<-20)||(Angle_Balance>10))                //角度过大 过小 停机
  {
    if( ntime==0 )
    {
    Moto_R=0;
    Moto_L=0;
    }
    //当是颠簸是关闭停车

  }
#ifdef UART_STOP_CAR  
  if(uart_get=='s')                //收到命令 停机
  {
    Moto_R=0;
    Moto_L=0;
  }
#endif
}
////// 第一次尝试圆环 效果非长不好        
////// {
//////        if( ad_L1.final==400&&(deal_position.poor>0) )              //L1先到400
//////          //400=FINAL,定义在ad.c
//////          //poor=L1-R2(右减左)
//////        {
//////          enter_flag=1;
//////        }
//////        if( ad_R2.final==400&&(deal_position.poor<0) )              //R2先到400
//////          //400=FINAL,定义在ad.c
//////        {
//////          R2_flag=1;
//////        }
//////       // if(deal_position.sum >)
//////        if(R2_flag==1  )
//////        {
//////          //if(deal_position.sum <)
//////         // if( (deal_position.L1_d>=3)||(deal_position.R2_d>=3) )  //当左右电感的微分大于 N时 出400范围
//////          if((ad_L1.final==400||ad_R2.final==400)&&deal_position.sum>370)
//////          {
//////            //R2_flag=0;
//////             buzzer_work_Mno();  
//////            Turn=-sum_encoder/10;                                 //sum_encoder/2*T   T=1/7E(大圆) T=2/9E(小圆) 这里T/2取0.1
//////          }
//////           else  buzzder_stop();
//////        }
//////        
//////        if( 1==enter_flag )
//////        {
//////          //if( (deal_position.L1_d>=3)||(deal_position.R2_d>=3) )   //当左右电感的微分大于 N时 出400范围
//////          if((ad_L1.final==400||ad_R2.final==400)&&deal_position.sum>460)
//////          {
//////           // enter_flag=0; 
//////             buzzer_work_Mno();  //flag清零
//////            Turn=sum_encoder/10;                                 //sum_encoder/2*T   T=1/7E(大圆) T=2/9E(小圆) 这里T/2取0.1
//////          } 
//////          else  buzzder_stop();
//////        }
//////        if(deal_position.sum <370)                                //当和比较小时，flag清零
//////        {
//////          enter_flag=0;
//////          R2_flag=0;
//////        }
//////  }       
//        deal_position.three_sum=ad_L1.final+ad_R2.final+ad_R1.final;
//        if(deal_position.three_sum>TANENCY_FLAG)
//        {
//          //ad_L1.final=0;
//          //Turn=5*Kd;                 //借kd一用 
//          tanency_flag=1;
//        }
//        //如果只用偏差小于20 那么当直道跑的时候也会被标flag
//        //考虑用中间电感做中间标志位 ，
//        //进园中间电感变化过程 ？升高下降 升高 再下降
//        if((absolute(deal_position.poor)<OUT_TANENCY_FLAG)
//           //&&(deal_position.sum<)
//             )                        //.sum不知道用不用
//        {
//          tanency_flag=0;
//        }
//        if( tanency_flag )
//        {
//          Turn=5*Kd;                 //借kd一用 
//        }
//
//又一次尝试
//       if( enter_flag==1&&deal_position.sum<300 )
//       {
//         if(deal_position.L1_d>deal_position.R2_d )
//         {
//          R2_flag=2; 
//         }
//         else R2_flag=1;
//       }
//       switch(R2_flag)
//       {
//       case 0:
//       break;
//       case 1:if( ad_L1.final>ad_R2.final )
//              {
//                Turn=-Turn*2;
//                Turn=Turn/3;
//              }
//       break;
//       case 2:if( ad_L1.final<ad_R2.final )
//              {
//                Turn=-Turn*2;
//                Turn=Turn/3;
//              }
//
//       break;
//       
//       default:;
//       }
//       if( R2_flag>0 )
//       {
//         n++;
//         if (n==5)  {R2_flag=0;enter_flag=0;}
//       }